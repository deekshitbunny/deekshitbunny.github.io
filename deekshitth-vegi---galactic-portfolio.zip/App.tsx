
import React, { useState, Suspense, useEffect, useCallback, useRef } from 'react';
import Scene from './components/Scene';
import HUD from './components/HUD';
import Chatbot from './components/Chatbot';
import Radar from './components/Radar';
import ExoplanetTool from './components/ExoplanetTool';
import { CelestialBodyData } from './types';
import { SOLAR_SYSTEM_DATA } from './data';
import { Loader } from '@react-three/drei';
import { LogOut, Navigation, MousePointer2, MessageSquare, Skull, Trophy, Settings, Play, ScanFace, Crosshair, ShieldAlert, X as XIcon, ChevronDown, Rocket as RocketIcon, Info, Move, Mouse, ArrowLeftCircle } from 'lucide-react';

const findBodyById = (id: string, body: CelestialBodyData): CelestialBodyData | null => {
  if (body.id === id) return body;
  if (body.moons) {
    for (const moon of body.moons) {
      const found = findBodyById(id, moon);
      if (found) return found;
    }
  }
  return null;
};

// ---- COUNTDOWN OVERLAY WITH INSTRUCTIONS ----
const CountdownOverlay = ({ onComplete }: { onComplete: () => void }) => {
    const [count, setCount] = useState(3);
    
    useEffect(() => {
        const timer = setInterval(() => {
            setCount(prev => {
                if (prev <= 1) {
                    clearInterval(timer);
                    setTimeout(onComplete, 500); 
                    return 0;
                }
                return prev - 1;
            });
        }, 1200); 
        return () => clearInterval(timer);
    }, [onComplete]);

    return (
        <div className="absolute inset-0 z-[200] flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm">
            <div className="scale-150 mb-12">
                 <h1 className={`text-9xl font-display font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500 drop-shadow-[0_0_25px_rgba(255,255,255,0.5)] transition-all duration-300 ${count === 0 ? 'scale-150 opacity-0' : 'scale-100 opacity-100'}`}>
                    {count > 0 ? count : 'ENGAGE'}
                </h1>
            </div>

            <div className={`grid grid-cols-3 gap-8 transition-opacity duration-500 ${count === 0 ? 'opacity-0' : 'opacity-100'}`}>
                 <div className="bg-cyan-950/30 border border-cyan-500/30 p-6 rounded-xl flex flex-col items-center backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.1)]">
                     <div className="flex space-x-1 mb-2">
                         <div className="w-8 h-8 border border-white/20 rounded flex items-center justify-center text-xs font-mono text-gray-500">A</div>
                         <div className="flex flex-col space-y-1">
                             <div className="w-8 h-8 border border-white rounded flex items-center justify-center text-xs font-mono font-bold bg-white text-black">W</div>
                             <div className="w-8 h-8 border border-white/20 rounded flex items-center justify-center text-xs font-mono text-gray-500">S</div>
                         </div>
                         <div className="w-8 h-8 border border-white/20 rounded flex items-center justify-center text-xs font-mono text-gray-500">D</div>
                     </div>
                     <span className="text-cyan-400 font-display tracking-widest text-sm mt-2">THRUSTERS</span>
                 </div>

                 <div className="bg-cyan-950/30 border border-cyan-500/30 p-6 rounded-xl flex flex-col items-center backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.1)]">
                     <div className="h-12 flex items-center justify-center">
                         <Mouse className="w-8 h-8 text-white animate-[pulse_2s_infinite]" />
                     </div>
                     <span className="text-cyan-400 font-display tracking-widest text-sm mt-2">LOOK & FIRE</span>
                 </div>

                 <div className="bg-cyan-950/30 border border-cyan-500/30 p-6 rounded-xl flex flex-col items-center backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.1)]">
                     <div className="h-12 flex items-center justify-center border border-white/50 px-3 rounded text-sm font-mono font-bold">
                         SHIFT
                     </div>
                     <span className="text-cyan-400 font-display tracking-widest text-sm mt-2">BOOST (20x)</span>
                 </div>
            </div>
            <div className={`mt-8 text-white/50 font-mono text-xs uppercase tracking-[0.2em] ${count === 0 ? 'opacity-0' : 'opacity-100'}`}>PREPARING SYSTEMS FOR FLIGHT...</div>
        </div>
    )
}

// ---- MOBILE CONTROLS OVERLAY ----
const MobileControls = ({ onInput }: { onInput: (data: {x: number, y: number, lookX: number, lookY: number}) => void }) => {
    const moveRef = useRef({ x: 0, y: 0 });
    const lookRef = useRef({ x: 0, y: 0 });

    useEffect(() => {
        let frameId: number;
        const loop = () => {
            onInput({ x: moveRef.current.x, y: moveRef.current.y, lookX: lookRef.current.x, lookY: lookRef.current.y });
            lookRef.current.x *= 0.5; lookRef.current.y *= 0.5;
            frameId = requestAnimationFrame(loop);
        };
        loop();
        return () => cancelAnimationFrame(frameId);
    }, [onInput]);

    return (
        <div className="absolute inset-0 z-50 pointer-events-none flex justify-between items-end p-8 pb-20 select-none">
            <div 
                className="w-32 h-32 bg-white/10 rounded-full border-2 border-white/30 backdrop-blur-sm pointer-events-auto relative touch-none shadow-[0_0_20px_rgba(255,255,255,0.2)]"
                onTouchStart={(e) => {
                    const touch = e.changedTouches[0];
                    const rect = (e.target as HTMLElement).getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    
                    const update = (t: React.Touch) => {
                        const dx = (t.clientX - centerX) / (rect.width/2);
                        const dy = -(t.clientY - centerY) / (rect.height/2);
                        moveRef.current = { x: Math.max(-1, Math.min(1, dx)), y: Math.max(-1, Math.min(1, dy)) };
                    };
                    update(touch);
                    
                    const moveHandler = (em: TouchEvent) => {
                        const tm = Array.from(em.changedTouches).find(x => x.identifier === touch.identifier);
                        if(tm) update(tm);
                    };
                    const endHandler = (ee: TouchEvent) => {
                        const te = Array.from(ee.changedTouches).find(x => x.identifier === touch.identifier);
                        if(te) { moveRef.current = { x: 0, y: 0 }; window.removeEventListener('touchmove', moveHandler); window.removeEventListener('touchend', endHandler); }
                    };
                    window.addEventListener('touchmove', moveHandler, { passive: false });
                    window.addEventListener('touchend', endHandler);
                }}
            >
                <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-white rounded-full -translate-x-1/2 -translate-y-1/2 opacity-50"></div>
                <div className="absolute -top-6 left-0 right-0 text-center text-[10px] text-white/50 font-mono font-bold">MOVE</div>
            </div>

            <div 
                className="w-32 h-32 bg-white/10 rounded-full border-2 border-white/30 backdrop-blur-sm pointer-events-auto relative touch-none shadow-[0_0_20px_rgba(255,255,255,0.2)]"
                onTouchStart={(e) => {
                    const touch = e.changedTouches[0];
                    let lastX = touch.clientX; let lastY = touch.clientY;
                    const moveHandler = (em: TouchEvent) => {
                        const tm = Array.from(em.changedTouches).find(x => x.identifier === touch.identifier);
                        if(tm) {
                            const deltaX = tm.clientX - lastX; const deltaY = tm.clientY - lastY;
                            lookRef.current = { x: deltaX * 0.5, y: deltaY * 0.5 };
                            lastX = tm.clientX; lastY = tm.clientY;
                        }
                    };
                    const endHandler = (ee: TouchEvent) => {
                        const te = Array.from(ee.changedTouches).find(x => x.identifier === touch.identifier);
                        if(te) { lookRef.current = { x: 0, y: 0 }; window.removeEventListener('touchmove', moveHandler); window.removeEventListener('touchend', endHandler); }
                    };
                    window.addEventListener('touchmove', moveHandler, { passive: false });
                    window.addEventListener('touchend', endHandler);
                }}
            >
                <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-white rounded-full -translate-x-1/2 -translate-y-1/2 opacity-50"></div>
                <div className="absolute -top-6 left-0 right-0 text-center text-[10px] text-white/50 font-mono font-bold">LOOK</div>
            </div>
        </div>
    );
};

const GameOverScreen = ({ onRespawn }: { onRespawn: () => void }) => {
    const [countdown, setCountdown] = useState(3);
    useEffect(() => {
        if (document.pointerLockElement) document.exitPointerLock();
        const timer = setInterval(() => {
            setCountdown((prev) => {
                if (prev <= 1) { clearInterval(timer); onRespawn(); return 0; }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(timer);
    }, [onRespawn]);

    return (
        <div className="fixed inset-0 bg-red-950/90 flex flex-col items-center justify-center backdrop-blur-sm" style={{ zIndex: 9999, cursor: 'auto' }}>
            <div className="relative border-4 border-red-500 p-12 bg-black/90 text-center shadow-[0_0_100px_red]">
                <Skull className="w-24 h-24 text-red-500 mx-auto mb-6 animate-pulse" />
                <h1 className="text-6xl font-display font-bold text-red-500 tracking-widest mb-4">CRITICAL FAILURE</h1>
                <p className="text-red-300 font-mono mb-8 text-xl">COLLISION DETECTED. HULL INTEGRITY COMPROMISED.</p>
                <div className="mt-8">
                    <p className="text-red-500 text-lg font-mono uppercase animate-pulse">AUTO-REBOOT SEQUENCE INITIATED...</p>
                    <h2 className="text-8xl font-display font-bold text-white mt-4">{countdown}</h2>
                </div>
            </div>
        </div>
    );
};

const PauseMenu = ({ onResume, sensitivity, setSensitivity }: { onResume: () => void, sensitivity: number, setSensitivity: (val: number) => void }) => (
    <div className="fixed inset-0 bg-black/80 flex flex-col items-center justify-center pointer-events-auto backdrop-blur-md" style={{ zIndex: 9998 }}>
        <div className="w-96 border border-cyan-500/50 bg-black p-8 rounded-lg shadow-[0_0_50px_rgba(6,182,212,0.3)]">
            <h2 className="text-3xl font-display text-white mb-8 tracking-widest text-center">SETTINGS</h2>
            <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                    <label className="text-cyan-400 font-mono text-sm uppercase">Mouse Sensitivity</label>
                    <span className="text-white font-mono">{sensitivity.toFixed(1)}</span>
                </div>
                <input type="range" min="0.1" max="10.0" step="0.1" value={sensitivity} onChange={(e) => setSensitivity(parseFloat(e.target.value))} className="w-full accent-cyan-500 h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer" />
            </div>
            <button onClick={onResume} className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 rounded flex items-center justify-center font-display tracking-widest transition-colors"><Play className="w-4 h-4 mr-2 fill-current" /> RESUME</button>
        </div>
    </div>
);

const RewardPopup = ({ name, description }: { name: string, description: string }) => (
    <div className="absolute top-32 left-1/2 transform -translate-x-1/2 z-50 animate-[slideDown_0.5s_ease-out]">
        <div className="bg-gradient-to-r from-yellow-900/90 to-black border-2 border-yellow-500 p-4 rounded-xl shadow-[0_0_50px_rgba(234,179,8,0.5)] flex items-center space-x-4 max-w-md">
            <div className="bg-yellow-500/20 p-3 rounded-full border border-yellow-500"><Trophy className="w-8 h-8 text-yellow-400" /></div>
            <div><h3 className="text-yellow-400 font-display font-bold tracking-wider text-lg">DATA ARTIFACT RECOVERED</h3><p className="text-white font-bold">{name}</p><p className="text-yellow-200/70 text-sm font-mono">{description}</p></div>
        </div>
    </div>
);

const ComingSoonPopup = ({ name }: { name: string }) => (
    <div className="absolute top-32 left-1/2 transform -translate-x-1/2 z-50 animate-[slideDown_0.5s_ease-out]">
        <div className="bg-gradient-to-r from-cyan-900/90 to-black border-2 border-cyan-500 p-4 rounded-xl shadow-[0_0_50px_rgba(6,182,212,0.5)] flex items-center space-x-4 max-w-md">
            <div className="bg-cyan-500/20 p-3 rounded-full border border-cyan-500"><RocketIcon className="w-8 h-8 text-cyan-400" /></div>
            <div><h3 className="text-cyan-400 font-display font-bold tracking-wider text-lg">SYSTEM LOCKED</h3><p className="text-white font-bold">{name}</p><p className="text-cyan-200/70 text-sm font-mono">Access Coming Soon...</p></div>
        </div>
    </div>
);

const NavigationHUD = ({ onNavigate }: { onNavigate: (id: string) => void }) => {
    return (
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 z-40 bg-black/80 border-b border-l border-r border-cyan-500/30 rounded-b-xl backdrop-blur-md px-8 py-3 flex items-center space-x-8 shadow-[0_5px_20px_rgba(6,182,212,0.1)]">
            <button onClick={() => onNavigate('sun')} className="flex items-center space-x-2 transition-all duration-300 hover:scale-105 group">
                <div className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse shadow-[0_0_10px_currentColor]"></div>
                <span className="text-xs font-mono font-bold tracking-widest uppercase text-yellow-500 group-hover:text-yellow-300">ABOUT</span>
            </button>
            {SOLAR_SYSTEM_DATA.moons?.map((planet) => (
                <div key={planet.id} className="relative group">
                    <button onClick={() => onNavigate(planet.id)} className="flex items-center space-x-2 transition-all duration-300 hover:scale-105">
                        <div className="w-3 h-3 rounded-full animate-pulse shadow-[0_0_10px_currentColor]" style={{ backgroundColor: planet.color }}></div>
                        <span className="text-xs font-mono font-bold tracking-widest uppercase transition-colors group-hover:text-white" style={{ color: planet.color }}>{planet.name}</span>
                        <ChevronDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-gray-400" />
                    </button>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 pt-2 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 pointer-events-none group-hover:pointer-events-auto">
                        <div className="bg-black/90 border border-gray-800 rounded-lg shadow-xl overflow-hidden py-1">
                            {planet.moons?.map((moon) => (
                                <button key={moon.id} onClick={() => onNavigate(moon.id)} className="block w-full text-left px-4 py-2 text-[10px] text-gray-300 hover:bg-white/10 hover:text-white font-mono uppercase tracking-wider transition-colors">{moon.name}</button>
                            ))}
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const Cockpit = ({ onExit, isChatOpen, toggleChat, onSettings, score, isDataOpen, onCloseData, speed }: { onExit: () => void, isChatOpen: boolean, toggleChat: () => void, onSettings: () => void, score: number, isDataOpen: boolean, onCloseData: () => void, speed: number }) => {
    const [isLocked, setIsLocked] = useState(false);
    useEffect(() => {
        const handleLockChange = () => setIsLocked(!!document.pointerLockElement);
        document.addEventListener('pointerlockchange', handleLockChange);
        handleLockChange();
        return () => document.removeEventListener('pointerlockchange', handleLockChange);
    }, []);
    useEffect(() => { if (isChatOpen && document.pointerLockElement) document.exitPointerLock(); }, [isChatOpen]);

    return (
        <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between overflow-hidden">
            <div className="absolute inset-0 z-0 pointer-events-none shadow-[inset_0_0_150px_rgba(0,0,0,0.9)] opacity-80 rounded-[50px] border-[30px] border-gray-900/80"></div>
            
            <div className="flex justify-between items-start relative z-[60] p-8 pointer-events-auto">
                
                {/* COMBAT SYSTEMS HUD - Now Static */}
                <div className="w-72 bg-black/80 border border-cyan-500/50 p-1 rounded-br-2xl backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.1)] group">
                    <div className="bg-cyan-950/30 p-4 rounded-br-xl relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/10 to-transparent h-2 w-full animate-[scan_2s_linear_infinite] opacity-50"></div>
                        
                        <div className="flex justify-between items-center border-b border-cyan-700/50 pb-2 mb-3">
                            <span className="font-display font-bold text-cyan-400 text-sm tracking-widest">COMBAT SYSTEMS</span>
                            <Crosshair className="w-4 h-4 text-red-500 animate-pulse" />
                        </div>

                        <div className="space-y-4 font-mono text-xs">
                            <div>
                                <div className="flex justify-between mb-1">
                                    <span className="text-cyan-600">VELOCITY</span>
                                    <span className="text-white font-bold text-lg">{speed} <span className="text-xs font-normal text-gray-400">KM/S</span></span>
                                </div>
                                <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                                    <div className="h-full bg-cyan-500 transition-all duration-100 shadow-[0_0_5px_cyan]" style={{ width: `${Math.min((speed / 200000) * 100, 100)}%` }}></div>
                                </div>
                            </div>

                            <div>
                                <div className="flex justify-between mb-1">
                                    <span className="text-cyan-600">HULL INTEGRITY (HEALTH)</span>
                                    <span className="text-green-400 font-bold">100%</span>
                                </div>
                                <div className="w-full bg-gray-800 h-1 rounded-full overflow-hidden">
                                    <div className="w-full h-full bg-green-500 shadow-[0_0_5px_lime]"></div>
                                </div>
                            </div>

                            <div className="flex justify-between items-center bg-gray-900/50 p-2 rounded border border-gray-700">
                                <span className="text-cyan-600">SCORE</span>
                                <span className="text-white font-display text-lg text-yellow-400">{score.toLocaleString()}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex flex-col space-y-2 items-end">
                    <div className="flex space-x-2">
                        <button onClick={onSettings} className="bg-gray-800/80 hover:bg-gray-700 p-2 rounded border border-gray-600/50 text-white transition-colors" title="Settings / Sensitivity"><Settings className="w-5 h-5" /></button>
                    </div>
                    <button onClick={toggleChat} className={`px-6 py-2 rounded font-display tracking-widest text-sm flex items-center transition-colors backdrop-blur-md border shadow-[0_0_15px_rgba(6,182,212,0.2)] ${isChatOpen ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200' : 'bg-cyan-950/60 hover:bg-cyan-900/80 border-cyan-500/30 text-cyan-400'}`}>
                        <MessageSquare className="w-4 h-4 mr-2" /> COMMS {isChatOpen ? 'OPEN' : 'OFFLINE'}
                    </button>
                    <div className="text-[10px] text-gray-500 font-mono mt-2 hidden md:block text-right">
                        PRESS 'F' FOR FLASHLIGHT • CLICK ⚙️ FOR SENSITIVITY <br/>
                        PRESS 'ESC' TO SHOW CURSOR
                    </div>
                </div>
            </div>

            {isLocked && !isChatOpen && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-80">
                    <div className="relative">
                        <div className="w-8 h-8 border border-red-500/50 rounded-full flex items-center justify-center"><div className="w-1 h-1 bg-red-500 rounded-full"></div></div>
                        <div className="absolute -left-4 top-1/2 w-3 h-0.5 bg-red-500/50"></div><div className="absolute -right-4 top-1/2 w-3 h-0.5 bg-red-500/50"></div><div className="absolute left-1/2 -top-4 w-0.5 h-3 bg-red-500/50"></div><div className="absolute left-1/2 -bottom-4 w-0.5 h-3 bg-red-500/50"></div>
                    </div>
                </div>
            )}

            {!isLocked && !isChatOpen && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-[4px] pointer-events-auto cursor-pointer z-50 transition-opacity duration-300" 
                    onClick={(e) => { e.stopPropagation(); const canvas = document.querySelector('canvas'); if (canvas) (canvas.requestPointerLock() as unknown as Promise<void>).catch(() => {}); }}
                >
                    <div className="text-center animate-pulse">
                        <MousePointer2 className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                        <h2 className="text-2xl font-display text-white tracking-widest border border-cyan-500 px-8 py-4 rounded bg-black/80 shadow-[0_0_20px_cyan]">ENGAGE MANUAL CONTROL</h2>
                        <p className="text-cyan-500 font-mono text-xs mt-4 tracking-wider">CLICK TO RESUME FLIGHT</p>
                    </div>
                </div>
            )}

            <div className="flex justify-center z-[100] pointer-events-auto pb-8 relative">
                 <button onClick={onExit} className="group bg-red-950/80 hover:bg-red-900 border-2 border-red-600/50 text-red-200 px-12 py-3 rounded-xl font-display font-bold tracking-[0.2em] shadow-[0_0_25px_rgba(220,38,38,0.4)] hover:shadow-[0_0_50px_red] transition-all duration-300 flex items-center transform hover:scale-105">
                    <LogOut className="w-5 h-5 mr-3 group-hover:rotate-180 transition-transform duration-500" />
                    DISENGAGE SYSTEM <span className="ml-3 text-[10px] opacity-70 border border-red-400/30 px-2 py-1 rounded bg-black/20 font-mono">PRESS X</span>
                 </button>
            </div>
        </div>
    );
};

const App = () => {
  const [focusedBody, setFocusedBody] = useState<CelestialBodyData | null>(null);
  const [isHudOpen, setIsHudOpen] = useState(false); 
  const [viewMode, setViewMode] = useState<'orbit' | 'spaceship'>('orbit');
  const [videoMode, setVideoMode] = useState<'launch' | 'death' | null>(null); 
  const [launchState, setLaunchState] = useState<'idle' | 'animating' | 'countdown' | 'flying'>('idle');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInitialPrompt, setChatInitialPrompt] = useState('');
  const [isDead, setIsDead] = useState(false);
  const [lastDeathTime, setLastDeathTime] = useState(0);
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>([]);
  const [currentReward, setCurrentReward] = useState<{name: string, description: string} | null>(null);
  const [comingSoonName, setComingSoonName] = useState<string | null>(null);
  const [mouseSensitivity, setMouseSensitivity] = useState(3.0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [score, setScore] = useState(0);
  const [speed, setSpeed] = useState(0); 
  const mobileInputRef = useRef({ x: 0, y: 0, lookX: 0, lookY: 0 });

  useEffect(() => {
      const checkMobile = () => setIsMobile(window.innerWidth < 768);
      checkMobile(); window.addEventListener('resize', checkMobile); return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
      fetch('/videos/launch.mp4', { method: 'HEAD' }).catch(err => console.log('Video check failed', err));
  }, []);

  const handleAiNavigation = (id: string) => {
    let target = findBodyById(id, SOLAR_SYSTEM_DATA);
    if (!target) {
        if (id === 'blackhole') {
            target = { id: 'blackhole', type: 'planet', name: 'TON 618', description: 'Supermassive Black Hole', color: '#000000', size: 12000, orbitRadius: 0, orbitSpeed: 0, details: ['Event Horizon Radius: 12,000 KM', 'Mass: 66 Billion Solar Masses', 'Status: Active'] } as CelestialBodyData;
        } else if (id.startsWith('rogue-')) {
             target = { id: id, type: 'planet', name: 'Alien System', description: 'Uncharted Star System', color: '#ffffff', size: 5000, orbitRadius: 0, orbitSpeed: 0, details: ['Scan required for further analysis.'] } as CelestialBodyData;
        }
    }
    if (target) {
        setFocusedBody(target);
        setIsHudOpen(true); // Automatically open HUD on navigation
    }
  };

  const handleManualFocus = (data: CelestialBodyData) => {
      setFocusedBody(data);
      setIsHudOpen(true);
  };

  const handleLaunch = () => { setFocusedBody(null); setVideoMode('launch'); };
  const handleVideoComplete = () => {
      if (videoMode === 'launch') { setVideoMode(null); setLaunchState('countdown'); } 
      else if (videoMode === 'death') { setVideoMode(null); setIsDead(true); }
  }
  const handleVideoError = () => {
      if (videoMode === 'launch') { setVideoMode(null); setLaunchState('animating'); } else { handleVideoComplete(); }
  }
  const handleLaunchAnimationComplete = useCallback(() => setLaunchState('countdown'), []);
  const handleCountdownComplete = useCallback(() => { setLaunchState('flying'); setViewMode('spaceship'); }, []);
  const handleChatRequest = (prompt: string) => { setChatInitialPrompt(prompt); setIsChatOpen(true); setIsHudOpen(false); };

  const handleDeath = useCallback((reason: 'collision' | 'blackhole' = 'collision') => {
    const now = Date.now();
    if (now - lastDeathTime > 3000) {
        if (reason === 'blackhole') { setVideoMode('death'); } else { setIsDead(true); }
        setLastDeathTime(now);
    }
  }, [lastDeathTime]);

  const handleRespawn = () => { setIsDead(false); setViewMode('orbit'); setLaunchState('idle'); };
  const handleReward = useCallback((name: string, description: string) => { if (!unlockedAchievements.includes(name)) { setUnlockedAchievements(prev => [...prev, name]); setCurrentReward({ name, description }); setTimeout(() => setCurrentReward(null), 5000); } }, [unlockedAchievements]);
  const handleScore = useCallback(() => setScore(s => s + 100), []);
  const handleSystemClick = useCallback((name: string) => { setComingSoonName(name); setTimeout(() => setComingSoonName(null), 4000); }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (isChatOpen) return;
        if (viewMode === 'spaceship' && !isDead) {
            if (e.key === 'Escape') { setIsPaused(prev => !prev); if (!isPaused) document.exitPointerLock(); }
            if (e.key.toLowerCase() === 'c' && focusedBody) setFocusedBody(null);
            if (e.key === 'Backspace' || e.key.toLowerCase() === 'x') { 
                document.exitPointerLock(); 
                setViewMode('orbit'); 
                setLaunchState('idle'); 
            }
        }
    };
    window.addEventListener('keydown', handleKeyDown); return () => window.removeEventListener('keydown', handleKeyDown);
  }, [viewMode, isDead, isPaused, focusedBody, isChatOpen]);

  // Determine HUD Visibility
  // 1. Planet Detail View: When HUD is explicitly open AND we have a focused body.
  const showPlanetHud = isHudOpen && focusedBody;
  // 2. Intro/Launch View: When no body is focused, we are in orbit mode, and haven't launched yet.
  const showIntroHud = !focusedBody && launchState === 'idle' && viewMode === 'orbit';

  return (
    <div className="w-screen h-screen bg-black overflow-hidden relative touch-none">
      <Suspense fallback={null}>
        <Scene 
            focusedBody={focusedBody} setFocusedBody={handleManualFocus} viewMode={viewMode} onDeath={handleDeath} isDead={isDead} onReward={handleReward} mouseSensitivity={mouseSensitivity} mobileInputRef={mobileInputRef} onScore={handleScore} onSystemClick={handleSystemClick} launchState={launchState === 'flying' ? 'flying' : (launchState === 'animating' ? 'animating' : undefined)} onLaunchComplete={handleLaunchAnimationComplete} score={score} onSpeedChange={setSpeed}
        />
      </Suspense>
      <Loader containerStyles={{ backgroundColor: 'black' }} barStyles={{ backgroundColor: '#06b6d4', height: '4px' }} dataStyles={{ color: '#06b6d4', fontSize: '14px', fontFamily: 'Orbitron' }} />
      
      {launchState === 'countdown' && <CountdownOverlay onComplete={handleCountdownComplete} />}
      
      {videoMode === 'launch' && (
          <div className="absolute inset-0 z-[200] bg-black">
            <video src="/videos/launch.mp4" className="w-full h-full object-cover" autoPlay playsInline onEnded={handleVideoComplete} onError={handleVideoError} style={{ objectFit: 'cover' }} />
            <button onClick={handleVideoComplete} className="absolute bottom-8 right-8 text-white/50 text-xs uppercase tracking-widest border border-white/20 px-4 py-2 hover:bg-white/10 z-[210] cursor-pointer">Skip Sequence</button>
        </div>
      )}
      {videoMode === 'death' && (
          <div className="absolute inset-0 z-[200] bg-black">
            <video src="/videos/blackhole_death.mp4" className="w-full h-full object-cover" autoPlay playsInline onEnded={handleVideoComplete} onError={handleVideoError} style={{ objectFit: 'cover' }} />
        </div>
      )}

      {isDead && !videoMode && <GameOverScreen onRespawn={handleRespawn} />}
      {isPaused && !isDead && viewMode === 'spaceship' && <PauseMenu onResume={() => setIsPaused(false)} sensitivity={mouseSensitivity} setSensitivity={setMouseSensitivity} />}
      {currentReward && <RewardPopup name={currentReward.name} description={currentReward.description} />}
      {comingSoonName && <ComingSoonPopup name={comingSoonName} />}

      <NavigationHUD onNavigate={handleAiNavigation} />

      {viewMode === 'spaceship' && !isDead && !isPaused && !videoMode && launchState === 'flying' && (
        <>
            <Cockpit onExit={() => { document.exitPointerLock(); setViewMode('orbit'); setLaunchState('idle'); }} isChatOpen={isChatOpen} toggleChat={() => setIsChatOpen(!isChatOpen)} onSettings={() => setIsPaused(true)} score={score} isDataOpen={!!focusedBody} onCloseData={() => setFocusedBody(null)} speed={speed} />
            {isMobile && <MobileControls onInput={(data) => { mobileInputRef.current = data; }} />}
        </>
      )}
      
      {/* HUD Rendering Logic */}
      {(showPlanetHud || showIntroHud) && (
          <HUD focusedBody={focusedBody} onClose={() => setIsHudOpen(false)} onLaunch={handleLaunch} onChat={handleChatRequest} onNavigate={handleManualFocus} viewMode={viewMode} />
      )}
      
      {/* RETURN TO ORBIT BUTTON (Visible when focused but HUD closed) */}
      {!isHudOpen && focusedBody && viewMode === 'orbit' && !videoMode && !isChatOpen && (
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-40 animate-fadeIn">
              <button 
                onClick={() => setFocusedBody(null)}
                className="flex items-center space-x-2 bg-black/60 backdrop-blur-md border border-cyan-500/30 px-6 py-2 rounded-full text-cyan-400 hover:text-white hover:bg-cyan-900/50 transition-all font-mono tracking-widest text-sm shadow-[0_0_20px_rgba(6,182,212,0.2)]"
              >
                  <ArrowLeftCircle className="w-4 h-4" />
                  <span>RETURN TO ORBIT</span>
              </button>
          </div>
      )}

      {focusedBody?.id === 'exoplanet_tool' && <ExoplanetTool onClose={() => setFocusedBody(null)} />}
      <Chatbot onNavigate={handleAiNavigation} isOpen={isChatOpen} setIsOpen={setIsChatOpen} initialPrompt={chatInitialPrompt} variant={viewMode === 'spaceship' ? 'hud' : 'default'} />

      {!focusedBody && viewMode === 'orbit' && !videoMode && !isChatOpen && launchState === 'idle' && (
          <div className="absolute bottom-4 left-0 right-0 text-center pointer-events-none">
              <p className="text-cyan-500/50 text-xs font-mono uppercase tracking-[0.2em] animate-pulse">System Online // Interaction Required</p>
          </div>
      )}
    </div>
  );
}

export default App;
