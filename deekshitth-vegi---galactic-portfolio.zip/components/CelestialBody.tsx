
import React, { useRef, useState, useEffect, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh, Vector3, Group, MathUtils, Color, BackSide, AdditiveBlending, ShaderMaterial, DoubleSide, SpriteMaterial, TextureLoader } from 'three';
import { Text, Html, Outlines, MeshDistortMaterial, useGLTF } from '@react-three/drei';
import { CelestialBodyData } from '../types';
import * as THREE from 'three';

interface CelestialBodyProps {
  data: CelestialBodyData;
  onFocus: (data: CelestialBodyData, position: Vector3) => void;
  focusedBodyId: string | null;
  viewMode?: 'orbit' | 'spaceship';
  registerRef?: (id: string, group: Group) => void;
  globalScale?: number;
}

const AtmosphereShader = {
  uniforms: {
    color: { value: new Color(0x000000) },
    coefficient: { value: 0.7 },
    power: { value: 2.0 },
  },
  vertexShader: `
    varying vec3 vNormal;
    void main() {
      vNormal = normalize(normalMatrix * normal);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 color;
    uniform float coefficient;
    uniform float power;
    varying vec3 vNormal;
    void main() {
      float intensity = pow(coefficient - dot(vNormal, vec3(0.0, 0.0, 1.0)), power);
      gl_FragColor = vec4(color, intensity);
    }
  `
};

const CoronaShader = {
  uniforms: {
    color: { value: new Color(0xFDB813) },
    viewVector: { value: new Vector3(0, 0, 0) },
    intensity: { value: 1.0 }, 
    power: { value: 4.0 } 
  },
  vertexShader: `
    uniform vec3 viewVector;
    varying float intensity;
    uniform float power;
    void main() {
      gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
      vec3 vNormal = normalize( normalMatrix * normal );
      vec3 vNormel = normalize( normalMatrix * viewVector );
      intensity = pow( 0.5 - abs(dot(vNormal, vNormel)), power );
    }
  `,
  fragmentShader: `
    uniform vec3 color;
    varying float intensity;
    void main() {
      vec3 glow = color * intensity;
      gl_FragColor = vec4( glow, 1.0 ) * intensity;
    }
  `
};

const RingShader = {
  uniforms: {
    color: { value: new Color(0xffffff) },
    innerRadius: { value: 0.5 },
    outerRadius: { value: 1.0 },
  },
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vPos;
    void main() {
      vUv = uv;
      vPos = position;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 color;
    varying vec2 vUv;
    varying vec3 vPos;

    float rand(vec2 co){
        return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
    }

    void main() {
        vec2 centered = vUv - 0.5;
        float dist = length(centered) * 2.0; 

        float bands = sin(dist * 200.0) * 0.5 + 0.5;
        float finerBands = sin(dist * 800.0) * 0.5 + 0.5;
        
        float noise = rand(vUv * 10.0);
        
        float pattern = (bands * 0.4 + finerBands * 0.3 + noise * 0.3);
        
        gl_FragColor = vec4(color, pattern * 0.8);
    }
  `
};

const getGlowTexture = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (ctx) {
        const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
        gradient.addColorStop(0, 'rgba(255, 200, 50, 0.8)'); 
        gradient.addColorStop(0.4, 'rgba(255, 100, 0, 0.2)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 64, 64);
    }
    return new THREE.CanvasTexture(canvas);
};


const ModelLoader = ({ path, scale }: { path: string, scale: number }) => {
    const { scene } = useGLTF(path);
    return <primitive object={scene} scale={scale} />;
}

const planetShaderLogic = {
    onBeforeCompile: (shader: any) => {
        shader.vertexShader = shader.vertexShader.replace(
            '#include <common>',
            `#include <common>
             varying vec3 vWorldPos;
             varying vec3 vSunDirView;
            `
        );
        shader.vertexShader = shader.vertexShader.replace(
            '#include <worldpos_vertex>',
            `#include <worldpos_vertex>
             vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
             
             vec3 sunDirWorld = normalize(vec3(0.0) - vWorldPos);
             vSunDirView = (viewMatrix * vec4(sunDirWorld, 0.0)).xyz;
            `
        );
        
        shader.fragmentShader = shader.fragmentShader.replace(
            '#include <common>',
            `#include <common>
             varying vec3 vWorldPos;
             varying vec3 vSunDirView;
            `
        );
        shader.fragmentShader = shader.fragmentShader.replace(
            '#include <emissivemap_fragment>',
            `#include <emissivemap_fragment>
             float sunDot = max(0.0, dot(vNormal, normalize(vSunDirView)));
             
             float dist = length(vWorldPos);
             float distFactor = clamp(6000.0 / (dist + 100.0), 0.0, 1.0);
             
             vec3 sunGlow = vec3(1.0, 0.8, 0.4); 
             totalEmissiveRadiance += sunGlow * sunDot * distFactor * 0.15;
            `
        );
    }
};

const CelestialBody: React.FC<CelestialBodyProps> = ({ 
    data, 
    onFocus, 
    focusedBodyId,
    viewMode = 'orbit',
    registerRef,
    globalScale = 1.0
}) => {
  const groupRef = useRef<Group>(null); 
  const meshRef = useRef<Mesh>(null);   
  const [hovered, setHover] = useState(false);
  
  const angleRef = useRef(Math.random() * Math.PI * 2);
  const currentSpeedRef = useRef(data.orbitSpeed);

  const isFocused = focusedBodyId === data.id;
  const glowTexture = useMemo(() => getGlowTexture(), []);
  
  const eccentricity = data.type === 'planet' ? 0.85 : 1.0;
  
  const scaledSize = data.size * globalScale;
  const scaledOrbitRadius = data.orbitRadius * globalScale;

  useEffect(() => {
    if (registerRef && groupRef.current) {
        registerRef(data.id, groupRef.current);
    }
  }, [data.id, registerRef]);

  useFrame((state, delta) => {
    if (meshRef.current) {
        if (!data.modelPath) {
            meshRef.current.rotation.y += data.rotationSpeed || 0.005;
        } else {
             meshRef.current.rotation.y += (data.rotationSpeed || 0.005) * 0.5;
        }

        const targetScale = isFocused ? scaledSize * 1.3 : (hovered ? scaledSize * 1.15 : scaledSize);
        const currentScale = meshRef.current.scale.x;
        const newScale = MathUtils.lerp(currentScale, targetScale, 0.1);
        meshRef.current.scale.set(newScale, newScale, newScale);
    }

    if (groupRef.current && scaledOrbitRadius > 0) {
        let targetSpeed = data.orbitSpeed;
        if (hovered) {
            targetSpeed = data.orbitSpeed * 0.1;
        }
        currentSpeedRef.current = MathUtils.lerp(currentSpeedRef.current, targetSpeed, 0.05);
        angleRef.current += currentSpeedRef.current * delta;

        const x = Math.cos(angleRef.current) * scaledOrbitRadius;
        const z = Math.sin(angleRef.current) * scaledOrbitRadius * eccentricity;
        
        groupRef.current.position.set(x, 0, z);
    }
  });

  const handleClick = (e: any) => {
    e.stopPropagation(); 
    if (meshRef.current) {
        const worldPos = new Vector3();
        meshRef.current.getWorldPosition(worldPos);
        onFocus(data, worldPos);
    }
  };

  const isSun = data.type === 'sun';
  const isPlanet = data.type === 'planet';
  const isMoon = data.type === 'moon';
  const orbitTilt = data.inclination || 0;
  const isLabelOccluded = viewMode === 'orbit';
  
  // Scale visual orbit width
  const orbitWidth = (data.orbitRadius > 2000 ? 30 : 8) * globalScale; 

  return (
    <group rotation={[orbitTilt, 0, 0]}>
        
        {scaledOrbitRadius > 0 && (
            // Visual Orbit Ring - INCREASED OPACITY to 0.8
            <mesh rotation={[-Math.PI / 2, 0, 0]} raycast={() => null} scale={[1, eccentricity, 1]}>
                <ringGeometry args={[scaledOrbitRadius - orbitWidth, scaledOrbitRadius + orbitWidth, 360]} />
                <meshBasicMaterial color={data.color} opacity={0.8} transparent side={DoubleSide} />
            </mesh>
        )}

        <group ref={groupRef}>
            <mesh 
              visible={false} 
              scale={[scaledSize * 1.4, scaledSize * 1.4, scaledSize * 1.4]} 
              onClick={handleClick}
              onPointerOver={() => { document.body.style.cursor = 'pointer'; setHover(true); }}
              onPointerOut={() => { document.body.style.cursor = 'auto'; setHover(false); }}
            >
                <sphereGeometry args={[1, 16, 16]} />
            </mesh>

            <group>
                <mesh
                    ref={meshRef}
                    onClick={handleClick}
                    onPointerOver={() => { document.body.style.cursor = 'pointer'; setHover(true); }}
                    onPointerOut={() => { document.body.style.cursor = 'auto'; setHover(false); }}
                    scale={[scaledSize, scaledSize, scaledSize]}
                >
                    {data.modelPath ? (
                        <React.Suspense fallback={<sphereGeometry args={[1, 16, 16]} />}>
                            <ModelLoader path={data.modelPath} scale={1} />
                        </React.Suspense>
                    ) : (
                        <>
                            <sphereGeometry args={[1, 64, 64]} />
                            {isSun ? (
                                <>
                                    <meshBasicMaterial color="#ffae00" />
                                    <mesh scale={[1.1, 1.1, 1.1]} raycast={() => null}>
                                        <sphereGeometry args={[1, 32, 32]} />
                                        <shaderMaterial
                                            attach="material"
                                            args={[CoronaShader]}
                                            uniforms-color-value={new Color("#ffae00")}
                                            side={BackSide} 
                                            transparent
                                            blending={AdditiveBlending}
                                            depthWrite={false}
                                        />
                                    </mesh>
                                    <sprite scale={[6, 6, 6]} raycast={() => null}>
                                        <spriteMaterial map={glowTexture} color="#FFD700" transparent blending={AdditiveBlending} depthWrite={false} opacity={0.8} />
                                    </sprite>
                                </>
                            ) : (
                                <meshPhysicalMaterial
                                    color={data.color}
                                    roughness={isMoon ? 0.4 : 0.8} // Moons are shinier
                                    metalness={isMoon ? 0.5 : 0.1} // Moons reflect more
                                    clearcoat={0.1}
                                    clearcoatRoughness={1}
                                    emissive={data.color}
                                    emissiveIntensity={isMoon ? 0.2 : 0.05} 
                                    onBeforeCompile={planetShaderLogic.onBeforeCompile}
                                />
                            )}
                        </>
                    )}

                    {(hovered || isFocused) && <Outlines thickness={(isSun ? 0.02 : 0.05) * globalScale} color="white" />}
                </mesh>

                {data.rings && data.rings.map((ring, idx) => (
                    <mesh 
                        key={idx} 
                        rotation={ring.rotation as any} 
                        position={[0,0,0]}
                        onClick={handleClick}
                        onPointerOver={() => { document.body.style.cursor = 'pointer'; setHover(true); }}
                        onPointerOut={() => { document.body.style.cursor = 'auto'; setHover(false); }}
                    >
                         <ringGeometry args={[ring.innerRadius * globalScale, ring.outerRadius * globalScale, 256]} />
                         <shaderMaterial 
                            args={[RingShader]}
                            uniforms-color-value={new Color(ring.color)}
                            side={DoubleSide}
                            transparent={true}
                            blending={AdditiveBlending}
                            depthWrite={false}
                         />
                    </mesh>
                ))}

                {isPlanet && !data.modelPath && (
                    <mesh scale={[scaledSize * 1.25, scaledSize * 1.25, scaledSize * 1.25]} raycast={() => null}>
                        <sphereGeometry args={[1, 32, 32]} />
                        <shaderMaterial
                            attach="material"
                            args={[AtmosphereShader]}
                            uniforms-color-value={new Color(data.color)}
                            side={BackSide} 
                            transparent
                            blending={AdditiveBlending}
                            depthWrite={false}
                        />
                    </mesh>
                )}
            </group>

            {!isFocused && (hovered || (viewMode === 'spaceship' && isPlanet) || (viewMode === 'spaceship' && isSun)) && (
                <Html 
                    position={[0, isSun ? scaledSize + (100 * globalScale) : scaledSize + (40 * globalScale), 0]} 
                    center 
                    distanceFactor={500 * globalScale}
                    occlude={isLabelOccluded}
                    style={{ pointerEvents: 'none' }}
                    zIndexRange={[100, 0]}
                >
                    <div className={`
                        px-3 py-1 rounded-full border backdrop-blur-md text-xs whitespace-nowrap font-display text-white transition-all duration-300
                        ${isSun ? 'border-yellow-500/50 bg-yellow-900/30' : 'border-cyan-500/50 bg-black/40'}
                        ${hovered ? 'scale-110 shadow-[0_0_15px_rgba(6,182,212,0.6)]' : 'opacity-70'}
                        ${viewMode === 'spaceship' ? 'border-2 font-bold shadow-[0_0_10px_rgba(255,255,255,0.3)]' : ''}
                    `}>
                        {data.name}
                        {viewMode === 'spaceship' && <span className="text-[10px] ml-1 opacity-70 block text-center tracking-widest">TARGET</span>}
                    </div>
                </Html>
            )}

            {data.moons?.map((moon) => (
                <CelestialBody
                    key={moon.id}
                    data={moon}
                    onFocus={onFocus}
                    focusedBodyId={focusedBodyId}
                    viewMode={viewMode}
                    registerRef={registerRef}
                    globalScale={globalScale}
                />
            ))}
        </group>
    </group>
  );
};

export default CelestialBody;
