
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Type, FunctionDeclaration, GenerateContentResponse } from "@google/genai";
import { Send, X, Bot, Cpu, Zap, Signal, MessageSquare, Compass, Star } from 'lucide-react';
import { SOLAR_SYSTEM_DATA, STAR_SYSTEM_TYPES } from '../data';

interface ChatbotProps {
  onNavigate: (id: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  initialPrompt?: string;
  variant?: 'default' | 'hud';
}

const SUGGESTIONS = [
    { label: "Visit Black Hole", prompt: "Take me to the Black Hole" },
    { label: "Find Binary System", prompt: "Show me a binary star system" },
    { label: "Find Trinary System", prompt: "Take me to a 3-star system" },
    { label: "Sun Bio", prompt: "Tell me about the creator" },
];

const Chatbot: React.FC<ChatbotProps> = ({ onNavigate, isOpen, setIsOpen, initialPrompt, variant = 'default' }) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { role: 'model', text: "SYSTEM ONLINE.\n\nAwaiting query regarding Subject: **Deekshitth Vegi** or Galactic Navigation." }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const hasTriggeredInitial = useRef(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && initialPrompt && !hasTriggeredInitial.current) {
        hasTriggeredInitial.current = true;
        handleSend(initialPrompt);
    }
    if (!isOpen) {
        hasTriggeredInitial.current = false;
    }
  }, [isOpen, initialPrompt]);

  const handleSend = async (overrideInput?: string) => {
    const textToSend = overrideInput || input;
    if (!textToSend.trim() || loading) return;

    // Build-time check: Ensure the API Key exists
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        setMessages(prev => [...prev, { role: 'user', text: textToSend }]);
        setMessages(prev => [...prev, { role: 'model', text: "SYSTEM ERROR: API Key missing.\n\n**FIX FOR DEPLOYMENT**:\n1. Create `.env.local` locally.\n2. Add `API_KEY=your_key`.\n3. Run `npm run build`.\n4. Upload `dist` folder." }]);
        console.error("API Key is undefined. Ensure .env exists with API_KEY during 'npm run build'.");
        return;
    }

    if (!overrideInput) setInput('');
    
    setMessages(prev => [...prev, { role: 'user', text: textToSend }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey });
      
      const navigateTool: FunctionDeclaration = {
        name: 'navigateTo',
        description: 'Moves the camera to focus on a specific celestial body, star system, or the black hole.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            targetId: {
              type: Type.STRING,
              description: 'The ID of the target. Standard IDs: sun, education, experience, projects, skills. Special IDs: "blackhole" for the black hole, "rogue-X" (where X is 0-24) for star systems.',
            },
          },
          required: ['targetId'],
        },
      };

      const systemInstruction = `
        You are VEGI-9000, an AI portfolio assistant and Galactic Navigator.
        
        **NAVIGATION DATA**:
        - **Black Hole**: ID is "blackhole".
        - **Experience Planet**: ID is "experience". (Also maps to "Work History", "Job Planet").
        - **Education Planet**: ID is "education".
        - **Projects Planet**: ID is "projects".
        - **Skills Planet**: ID is "skills".
        - **Star Systems**: There are ${STAR_SYSTEM_TYPES.length} rogue star systems orbiting the black hole.
          - Binary Systems: Indices where type is 'binary' in [${STAR_SYSTEM_TYPES.join(', ')}]. (e.g., rogue-0, rogue-1).
          - Trinary Systems: Indices where type is 'trinary'. (e.g., rogue-2).
          - Single Systems: All others.
        - **Resume Data**:
          ${JSON.stringify(SOLAR_SYSTEM_DATA)}

        **INSTRUCTIONS**:
        - If user asks to see a binary/trinary system, pick a valid "rogue-X" ID and call navigateTo.
        - If user asks for Black Hole, call navigateTo("blackhole").
        - If user asks for "Experience Planet" or similar, call navigateTo("experience").
        - **Format**: Use Markdown. **Bold** key terms. Bullet points for lists.
        - Tone: Robotic but helpful.
      `;

      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
            ...messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
            { role: 'user', parts: [{ text: textToSend }] }
        ],
        config: {
          systemInstruction: systemInstruction,
          tools: [{ functionDeclarations: [navigateTool] }]
        }
      });

      const toolCalls = response.candidates?.[0]?.content?.parts?.find(p => p.functionCall);
      
      if (toolCalls) {
        const functionCall = toolCalls.functionCall;
        if (functionCall && functionCall.name === 'navigateTo') {
            const args = functionCall.args as any;
            onNavigate(args.targetId);
            
            const toolResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: [
                    ...messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
                    { role: 'user', parts: [{ text: textToSend }] },
                    { role: 'model', parts: [toolCalls] },
                    { 
                        role: 'function', 
                        parts: [{ 
                            functionResponse: {
                                name: 'navigateTo',
                                response: { result: `Navigation initiated to ${args.targetId}.` }
                            }
                        }] 
                    }
                ]
            });
            
            setMessages(prev => [...prev, { role: 'model', text: toolResponse.text || `Course laid in for ${args.targetId}.` }]);
        }
      } else {
        setMessages(prev => [...prev, { role: 'model', text: response.text || "Data corrupted." }]);
      }

    } catch (error: any) {
      console.error("Gemini API Error:", error);
      
      let errorMessage = error.message || 'Connection severed.';
      
      // Try to parse JSON error if present (Common with Google API 400s)
      try {
          if (errorMessage.includes('{')) {
              const jsonPart = errorMessage.substring(errorMessage.indexOf('{'));
              const parsed = JSON.parse(jsonPart);
              if (parsed.error && parsed.error.message) {
                  errorMessage = parsed.error.message;
              }
          }
      } catch (e) { /* ignore parse error */ }

      let helpText = "";
      if (errorMessage.includes("API key not valid") || !apiKey) {
          helpText = "\n\n**CONFIGURATION ERROR**:\nThe API Key is invalid or missing.\n\n**FIX FOR HOSTINGER/STATIC SITES**:\n1. Create a file named `.env.local` in your project root.\n2. Add `API_KEY=AIza...` (your actual key).\n3. Run `npm run build` again locally.\n4. Upload the new `dist` folder contents.";
      }

      setMessages(prev => [...prev, { 
          role: 'model', 
          text: `ERR: ${errorMessage}${helpText}` 
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  const renderFormattedText = (text: string) => {
    return text.split('\n').map((line, i) => (
      <div key={i} className={`min-h-[1.2em] ${line.trim() === '' ? 'h-2' : 'mb-1'}`}>
        {line.split(/(\*\*.*?\*\*)/g).map((part, j) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={j} className="text-white font-bold">{part.slice(2, -2)}</strong>;
          }
          return <span key={j}>{part}</span>;
        })}
      </div>
    ));
  };

  const isHud = variant === 'hud';

  return (
    <div className={`fixed z-[90] flex flex-col pointer-events-auto font-mono transition-all duration-300 ${isHud ? 'bottom-24 right-8 items-end' : 'bottom-4 right-4 items-end'}`}>
      
      {/* Chat Window */}
      {isOpen && (
        <div className={`
            flex flex-col overflow-hidden transition-all duration-300 relative group
            ${isHud 
                ? 'w-96 h-[500px] bg-cyan-950/10 backdrop-blur-[2px] border-l-2 border-r border-t border-b border-cyan-500/30 rounded-tl-2xl rounded-br-2xl shadow-[0_0_50px_rgba(6,182,212,0.1)]' 
                : 'w-80 md:w-96 h-[500px] bg-black/90 backdrop-blur-md border border-cyan-500/50 rounded-lg shadow-[0_0_30px_rgba(6,182,212,0.3)] mb-6'
            }
        `}>
          {/* HUD Scanline Effect */}
          {isHud && (
             <div className="absolute inset-0 pointer-events-none z-0 bg-[linear-gradient(rgba(18,255,255,0)_50%,rgba(0,255,255,0.05)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_2px,3px_100%]"></div>
          )}

          {/* Header */}
          <div className={`
            p-3 flex justify-between items-center z-10 
            ${isHud ? 'bg-cyan-900/20 border-b border-cyan-500/30' : 'bg-cyan-950/80 border-b border-cyan-500/50'}
          `}>
            <div className="flex items-center text-cyan-400">
              {isHud ? <Signal className="w-4 h-4 mr-2 animate-pulse text-cyan-300" /> : <Cpu className="w-4 h-4 mr-2 animate-pulse" />}
              <span className="tracking-[0.2em] text-xs font-bold uppercase text-cyan-300 shadow-cyan-500 drop-shadow-[0_0_5px_rgba(6,182,212,0.5)]">
                {isHud ? 'COMMS LINK // SECURE' : 'VEGI-9000 // CORE'}
              </span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-cyan-600 hover:text-white transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 z-10 custom-scrollbar relative">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] p-2 text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'text-cyan-200 border-r-2 border-cyan-500/50 pr-3 text-right bg-cyan-900/10' 
                    : isHud ? 'text-green-300 drop-shadow-[0_0_2px_rgba(0,255,0,0.4)]' : 'text-green-400'
                }`}>
                  {msg.role === 'model' && !isHud && <Bot className="w-4 h-4 mb-2 opacity-70" />}
                  <div className="whitespace-pre-wrap">{renderFormattedText(msg.text)}</div>
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="flex justify-start animate-pulse">
                 <div className="text-green-500 font-mono text-xs flex items-center">
                    <span className="w-2 h-4 bg-green-500 mr-1"></span> {isHud ? 'INCOMING TRANSMISSION...' : 'PROCESSING REQUEST...'}
                 </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggestions */}
          {!loading && (
              <div className="px-4 py-2 flex gap-2 overflow-x-auto scrollbar-hide z-10 bg-transparent">
                  {SUGGESTIONS.map((s, i) => (
                      <button 
                        key={i} 
                        onClick={() => handleSend(s.prompt)}
                        className={`text-[10px] whitespace-nowrap px-2 py-1 rounded border transition-colors ${
                            isHud ? 'border-cyan-700 text-cyan-400 hover:bg-cyan-900/50' : 'border-gray-700 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                          {s.label}
                      </button>
                  ))}
              </div>
          )}

          {/* Input */}
          <div className={`
             p-3 z-10 flex items-center
             ${isHud ? 'bg-cyan-950/20 border-t border-cyan-500/30' : 'bg-black border-t border-cyan-800'}
          `}>
            {isHud ? <div className="w-2 h-2 bg-cyan-500 rounded-full mr-3 animate-pulse"></div> : <Zap className="w-4 h-4 text-yellow-500 mr-2" />}
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={isHud ? "TRANSMIT MESSAGE..." : "ENTER COMMAND..."}
              className={`flex-1 bg-transparent border-none outline-none text-sm font-mono placeholder-cyan-800 ${isHud ? 'text-cyan-100' : 'text-cyan-100'}`}
            />
            <button 
              onClick={() => handleSend()}
              disabled={loading}
              className="p-2 text-cyan-500 hover:text-cyan-300 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Floating Toggle Button - Only shown in default mode */}
      {!isHud && (
        <button 
            onClick={() => setIsOpen(!isOpen)}
            className="group relative flex items-center justify-center w-14 h-14 bg-black/80 border border-cyan-500 rounded-full shadow-[0_0_15px_rgba(6,182,212,0.4)] hover:scale-105 transition-transform"
        >
            <div className="absolute inset-0 rounded-full border border-cyan-400 opacity-30 animate-ping"></div>
            {isOpen ? <X className="w-6 h-6 text-cyan-400" /> : <Bot className="w-6 h-6 text-cyan-400" />}
        </button>
      )}
    </div>
  );
};

export default Chatbot;
