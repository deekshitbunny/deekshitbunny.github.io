
import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, Activity, CheckCircle, Database, Zap, Clock, Globe } from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Line, Stars } from '@react-three/drei';
import * as THREE from 'three';
import '../types';

const ExoplanetVis = ({ predictedClass }: { predictedClass: string }) => {
    const planetRef = useRef<THREE.Mesh>(null);
    const [angle, setAngle] = useState(0);
    // Adjusted for MASSIVE star (50,000 radius)
    const orbitRadius = 60000.0; 
    
    // Create orbit path points
    const points = [];
    for (let i = 0; i <= 128; i++) {
        const theta = (i / 128) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta) * orbitRadius, 0, Math.sin(theta) * orbitRadius));
    }

    useFrame((state, delta) => {
        setAngle(prev => prev + delta * 0.5);
        if (planetRef.current) {
            planetRef.current.position.x = Math.cos(angle) * orbitRadius;
            planetRef.current.position.z = Math.sin(angle) * orbitRadius;
        }
    });

    if (predictedClass !== 'Transit') {
        return (
            <group>
                 <mesh position={[0,0,0]}>
                    <sphereGeometry args={[200, 32, 32]} />
                    <meshStandardMaterial color="#444" wireframe />
                 </mesh>
                 <Stars radius={100} count={2000} factor={4} fade speed={1} />
            </group>
        )
    }

    return (
        <group rotation={[0.4, 0, 0]}>
            {/* Star - Radius Increased to 50000 (MASSIVE) */}
            <mesh>
                <sphereGeometry args={[50000, 128, 128]} />
                <meshStandardMaterial color="#FDB813" emissive="#FDB813" emissiveIntensity={1.0} />
                <pointLight intensity={3} distance={200000} color="orange" />
            </mesh>
            
            {/* Glow */}
            <mesh scale={[1.02, 1.02, 1.02]}>
                <sphereGeometry args={[50000, 64, 64]} />
                <meshBasicMaterial color="#FFD700" transparent opacity={0.1} side={THREE.BackSide} />
            </mesh>

            {/* Orbit Path */}
            <Line points={points} color="cyan" lineWidth={2} opacity={0.5} transparent />

            {/* Planet - Scaled up */}
            <mesh ref={planetRef}>
                <sphereGeometry args={[800, 32, 32]} />
                <meshStandardMaterial color="#111" roughness={0.8} />
                <mesh scale={[1.05, 1.05, 1.05]}>
                    <sphereGeometry args={[800, 32, 32]} />
                    <meshBasicMaterial color="cyan" wireframe transparent opacity={0.3} />
                </mesh>
            </mesh>
             
             <Stars radius={500000} count={10000} factor={4} fade speed={1} />
        </group>
    );
};

interface ExoplanetToolProps {
    onClose: () => void;
}

const ExoplanetTool: React.FC<ExoplanetToolProps> = ({ onClose }) => {
    const [file, setFile] = useState<File | null>(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [result, setResult] = useState<any | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
            setResult(null);
        }
    };

    const handleAnalyze = () => {
        if (!file) return;
        setAnalyzing(true);
        setTimeout(() => {
            setAnalyzing(false);
            const isTransit = Math.random() > 0.3; 
            setResult({
                predictedClass: isTransit ? "Transit" : "No Transit",
                confidence: (85 + Math.random() * 14).toFixed(2),
                radius: (0.8 + Math.random() * 0.5).toFixed(4),
                duration: (2.5 + Math.random() * 4).toFixed(4),
                period: (300 + Math.random() * 200).toFixed(4)
            });
        }, 2000);
    };

    return (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-[fadeIn_0.3s_ease-out]">
            <div className="w-full max-w-5xl bg-black border border-gray-800 rounded-2xl overflow-hidden shadow-[0_0_100px_rgba(147,51,234,0.15)] flex flex-col md:flex-row h-[700px] relative">
                
                <div className="absolute inset-0 bg-[linear-gradient(rgba(147,51,234,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(147,51,234,0.05)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none"></div>

                <div className="md:w-5/12 p-8 border-r border-gray-800 flex flex-col relative z-10 bg-black/80">
                    <button onClick={onClose} className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors">
                        <X className="w-6 h-6" />
                    </button>

                    <div className="mb-8">
                        <div className="flex items-center space-x-2 mb-2">
                             <Database className="w-5 h-5 text-purple-500" />
                             <span className="text-purple-500 font-mono text-xs tracking-widest uppercase">Analysis Module 01</span>
                        </div>
                        <h2 className="text-3xl font-display font-bold text-white tracking-wide">
                            EXOPLANET <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">DETECTOR</span>
                        </h2>
                        <p className="text-gray-400 text-sm mt-2 font-light">
                            Upload light curve data (CSV) to identify transit events using Deep Learning Transformer models.
                        </p>
                    </div>

                    <div className="space-y-6 flex-1">
                        <div className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center transition-all duration-300 group
                            ${file ? 'border-purple-500/50 bg-purple-900/10' : 'border-gray-800 hover:border-gray-600 hover:bg-gray-900/50'}
                        `}>
                            <Upload className={`w-10 h-10 mb-3 transition-colors ${file ? 'text-purple-400' : 'text-gray-500 group-hover:text-gray-300'}`} />
                            <label className="cursor-pointer relative z-20">
                                <span className="text-sm font-bold text-white hover:text-purple-400 transition-colors">Click to Upload CSV</span>
                                <input type="file" className="hidden" accept=".csv" onChange={handleFileChange} />
                            </label>
                            <p className="text-xs text-gray-500 mt-2">Required format: 1000 flux points</p>
                            {file && (
                                <div className="mt-4 bg-purple-500/20 text-purple-200 text-xs px-3 py-1.5 rounded-full flex items-center border border-purple-500/30">
                                    <CheckCircle className="w-3 h-3 mr-2" />
                                    {file.name}
                                </div>
                            )}
                        </div>

                        <button 
                            onClick={handleAnalyze}
                            disabled={!file || analyzing}
                            className={`w-full py-4 rounded-lg font-display font-bold tracking-widest text-sm transition-all duration-300 relative overflow-hidden
                                ${!file ? 'bg-gray-900 text-gray-600 cursor-not-allowed' :
                                analyzing ? 'bg-purple-900 text-purple-200' :
                                'bg-white text-black hover:bg-purple-400 hover:text-white hover:shadow-[0_0_30px_rgba(192,132,252,0.4)]'}
                            `}
                        >
                            {analyzing ? (
                                <div className="flex items-center justify-center">
                                    <Activity className="w-4 h-4 mr-2 animate-spin" /> PROCESSING DATA...
                                </div>
                            ) : (
                                "RUN ANALYSIS"
                            )}
                        </button>
                    </div>
                    
                    {result && (
                         <div className="grid grid-cols-2 gap-3 mt-6 animate-[slideUp_0.4s_ease-out]">
                             <div className="col-span-2 bg-gray-900/50 p-4 rounded-lg border border-gray-800 flex justify-between items-center">
                                 <span className="text-gray-400 text-xs uppercase font-mono">Prediction</span>
                                 <span className={`text-xl font-bold font-display ${result.predictedClass === 'Transit' ? 'text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.5)]' : 'text-yellow-500'}`}>
                                     {result.predictedClass.toUpperCase()}
                                 </span>
                             </div>
                             
                             <div className="bg-gray-900/50 p-3 rounded-lg border border-gray-800">
                                 <div className="flex items-center text-purple-400 mb-1"><Zap className="w-3 h-3 mr-1" /> <span className="text-[10px] uppercase">Confidence</span></div>
                                 <div className="text-lg font-mono text-white">{result.confidence}%</div>
                             </div>
                             
                             <div className="bg-gray-900/50 p-3 rounded-lg border border-gray-800">
                                 <div className="flex items-center text-blue-400 mb-1"><Globe className="w-3 h-3 mr-1" /> <span className="text-[10px] uppercase">Radius</span></div>
                                 <div className="text-lg font-mono text-white">{result.radius}</div>
                             </div>

                             {result.predictedClass === 'Transit' && (
                                <>
                                 <div className="bg-gray-900/50 p-3 rounded-lg border border-gray-800">
                                     <div className="flex items-center text-pink-400 mb-1"><Clock className="w-3 h-3 mr-1" /> <span className="text-[10px] uppercase">Duration</span></div>
                                     <div className="text-lg font-mono text-white">{result.duration}h</div>
                                 </div>
                                 <div className="bg-gray-900/50 p-3 rounded-lg border border-gray-800">
                                     <div className="flex items-center text-orange-400 mb-1"><Activity className="w-3 h-3 mr-1" /> <span className="text-[10px] uppercase">Period</span></div>
                                     <div className="text-lg font-mono text-white">{result.period}d</div>
                                 </div>
                                </>
                             )}
                         </div>
                    )}
                </div>

                <div className="md:w-7/12 bg-black relative">
                    <div className="absolute top-6 left-6 z-20">
                        <div className="bg-black/60 backdrop-blur border border-gray-700 px-4 py-2 rounded-full flex items-center">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse mr-2"></div>
                            <span className="text-xs text-white font-mono tracking-wider">LIVE ORBIT SIMULATION</span>
                        </div>
                    </div>

                    {!result && !analyzing && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <div className="w-64 h-64 border border-gray-800 rounded-full flex items-center justify-center opacity-30">
                                <div className="w-48 h-48 border border-gray-800 rounded-full"></div>
                            </div>
                            <p className="mt-8 text-gray-600 font-mono text-xs tracking-[0.2em]">WAITING FOR TELEMETRY</p>
                        </div>
                    )}

                    <Canvas camera={{ position: [100000, 20000, 100000], fov: 60, far: 500000 }}>
                        <OrbitControls autoRotate={!!result} autoRotateSpeed={0.5} enableZoom={true} />
                        <color attach="background" args={['#020202']} />
                        <ambientLight intensity={0.2} />
                        <Stars radius={200000} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
                        
                        {result && <ExoplanetVis predictedClass={result.predictedClass} />}
                    </Canvas>
                </div>
            </div>
        </div>
    );
};

export default ExoplanetTool;
