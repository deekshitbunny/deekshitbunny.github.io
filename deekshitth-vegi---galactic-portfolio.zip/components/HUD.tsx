
import React, { useEffect, useState, useRef, useMemo } from 'react';
import { CelestialBodyData } from '../types';
import { X, ExternalLink, Rocket, Scan, Activity, Database, Cpu, MessageCircleQuestion, Globe, Disc, Orbit, User, MapPin, ArrowUpLeft, GraduationCap, Linkedin, Github, Smile, FileDown } from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars, Outlines, Float, Html } from '@react-three/drei';
import * as THREE from 'three';
import { SOLAR_SYSTEM_DATA } from '../data';

interface HUDProps {
  focusedBody: CelestialBodyData | null;
  onClose: () => void;
  onLaunch: () => void;
  onChat: (initialPrompt: string) => void;
  onNavigate: (data: CelestialBodyData) => void;
  viewMode: 'orbit' | 'spaceship';
}

const findParentBody = (id: string, body: CelestialBodyData): CelestialBodyData | null => {
    if (body.moons) {
        for (const moon of body.moons) {
            if (moon.id === id) return body;
            const found = findParentBody(id, moon);
            if (found) return found;
        }
    }
    return null;
}

const MiniPlanet = ({ data, onClick, isMoon = false, index = 0, totalSiblings = 1 }: { data: CelestialBodyData, onClick: (d: CelestialBodyData) => void, isMoon?: boolean, index?: number, totalSiblings?: number }) => {
    const meshRef = useRef<THREE.Mesh>(null);
    const groupRef = useRef<THREE.Group>(null);
    const [hovered, setHover] = useState(false);

    // Calculate position based on index to distribute in a circle
    const position = useMemo(() => {
        if (!isMoon) return new THREE.Vector3(0, 0, 0);
        const radius = 6 + (index % 2) * 1.5; // Stagger radii slightly
        const angle = (index / totalSiblings) * Math.PI * 2;
        return new THREE.Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
    }, [isMoon, index, totalSiblings]);

    useFrame((state, delta) => {
        if (meshRef.current) {
            meshRef.current.rotation.y += delta * 0.5;
        }
        if (groupRef.current && isMoon) {
            // Orbit animation around center (0,0,0)
            groupRef.current.rotation.y += delta * 0.2;
        }
    });

    const handlePointerOver = (e: any) => {
        e.stopPropagation();
        setHover(true);
        document.body.style.cursor = 'pointer';
    };

    const handlePointerOut = (e: any) => {
        e.stopPropagation();
        setHover(false);
        document.body.style.cursor = 'auto';
    };

    const handleClick = (e: any) => {
        e.stopPropagation();
        onClick(data);
    };

    return (
        <group rotation={[0, (index / totalSiblings) * Math.PI * 2, 0]}> {/* Initial rotation offset */}
            <group ref={groupRef}>
                {/* Main Body */}
                <mesh 
                    ref={meshRef} 
                    scale={[1,1,1]} 
                    position={[isMoon ? 6 : 0, 0, 0]} // Fixed radius from center group rotation
                    onClick={handleClick}
                    onPointerOver={handlePointerOver}
                    onPointerOut={handlePointerOut}
                >
                    <sphereGeometry args={[isMoon ? 0.8 : 2.2, 64, 64]} />
                    {data.type === 'sun' ? (
                        <>
                            <meshBasicMaterial color={data.color} />
                            <pointLight intensity={2} distance={10} color={data.color} />
                        </>
                    ) : (
                        <meshStandardMaterial 
                            color={data.color} 
                            roughness={0.6} 
                            metalness={0.2} 
                            emissive={data.color}
                            emissiveIntensity={hovered ? 0.3 : 0.1}
                        />
                    )}
                    
                    {hovered && (
                        <Html distanceFactor={10} zIndexRange={[100, 0]}>
                            <div className="bg-black/80 px-2 py-1 rounded text-xs border border-cyan-500/50 text-white whitespace-nowrap backdrop-blur-sm pointer-events-none">
                                {data.name}
                            </div>
                        </Html>
                    )}
                </mesh>
                
                {/* Rings - Only if defined */}
                {data.rings && data.rings.map((ring, i) => (
                    <mesh key={i} rotation={[Math.PI/3, 0, 0]} position={[isMoon ? 6 : 0, 0, 0]}>
                        <ringGeometry args={[3, 4.5, 64]} />
                        <meshStandardMaterial 
                            color={ring.color} 
                            side={THREE.DoubleSide} 
                            transparent 
                            opacity={ring.opacity} 
                        />
                    </mesh>
                ))}

                {/* Recursively render moons if this is the main body */}
                {!isMoon && data.moons?.map((moon, i) => (
                    <MiniPlanet key={moon.id} data={moon} onClick={onClick} isMoon={true} index={i} totalSiblings={data.moons!.length} />
                ))}
            </group>
        </group>
    );
}

const BodyPreview = ({ data, onNavigate }: { data: CelestialBodyData, onNavigate: (d: CelestialBodyData) => void }) => {
    return (
        <group>
            <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
                <MiniPlanet data={data} onClick={onNavigate} />
            </Float>
            <ambientLight intensity={0.4} />
            <pointLight position={[10, 10, 10]} intensity={2} />
            <pointLight position={[-10, -10, -10]} intensity={0.5} color="#4c1d95" />
            <Stars radius={50} depth={50} count={1000} factor={4} saturation={0} fade speed={1} />
        </group>
    );
}

const HUD: React.FC<HUDProps> = ({ focusedBody, onClose, onLaunch, onChat, onNavigate, viewMode }) => {
  const [scanProgress, setScanProgress] = useState(0);
  const [parentBody, setParentBody] = useState<CelestialBodyData | null>(null);

  useEffect(() => {
    if (focusedBody) {
        setScanProgress(0);
        const interval = setInterval(() => {
            setScanProgress(prev => {
                if (prev >= 100) {
                    clearInterval(interval);
                    return 100;
                }
                return prev + 10;
            });
        }, 20);
        
        // Find parent if it exists (for sibling recommendations)
        if (focusedBody.type === 'moon') {
            const p = findParentBody(focusedBody.id, SOLAR_SYSTEM_DATA);
            setParentBody(p);
        } else {
            setParentBody(null);
        }

        return () => clearInterval(interval);
    }
  }, [focusedBody]);

  if (viewMode === 'spaceship' && !focusedBody) return null;
  if (focusedBody?.id === 'exoplanet_tool') return null;

  if (!focusedBody) {
    return (
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-8 left-8 text-white select-none pointer-events-auto">
          <div className="flex items-center space-x-3 mb-2 opacity-70">
            <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span className="text-xs font-mono text-cyan-400 tracking-[0.2em]">SYSTEM ONLINE</span>
          </div>
          <h1 className="text-6xl font-bold font-display tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-cyan-500 drop-shadow-[0_0_15px_rgba(6,182,212,0.5)]">
            DEEKSHITTH VEGI
          </h1>
          <h2 className="text-xl text-cyan-200 mt-2 font-light tracking-[0.3em] uppercase border-l-2 border-cyan-500 pl-4 bg-gradient-to-r from-cyan-900/30 to-transparent">
            AI / ML Engineer & Researcher
          </h2>
          <div className="mt-8">
            <button 
                onClick={onLaunch}
                className="group relative px-8 py-4 overflow-hidden rounded bg-cyan-950/50 text-white shadow-[0_0_20px_rgba(6,182,212,0.2)] border border-cyan-500/30 hover:border-cyan-400 transition-all duration-300"
            >
                <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-cyan-600 to-blue-600 opacity-0 group-hover:opacity-20 transition-opacity"></div>
                <div className="flex items-center space-x-3 relative z-10">
                    <Rocket className="w-5 h-5 group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform duration-500" />
                    <span className="font-display tracking-widest font-bold">CLICK TO INITIATE SPACESHIP LAUNCH</span>
                </div>
            </button>
          </div>
        </div>
    </div>
    );
  }

  // Determine which list to show at the bottom
  const isSpecialObject = focusedBody.id === 'blackhole' || focusedBody.id.startsWith('rogue-');
  const isEducationMoon = parentBody?.id === 'education' || focusedBody.id === 'unt' || focusedBody.id === 'iiitdm';
  const isSun = focusedBody.id === 'sun';
  
  // Recommendation Logic
  let recommendedItems: CelestialBodyData[] = [];
  let recommendationTitle = "";

  if (!isSpecialObject) {
      if (focusedBody.type === 'moon' && parentBody && parentBody.moons) {
          // Recommend siblings
          recommendedItems = parentBody.moons.filter(m => m.id !== focusedBody.id);
          recommendationTitle = `SIBLING SATELLITES (${parentBody.name})`;
      } else {
          // Recommend other planets
          recommendedItems = SOLAR_SYSTEM_DATA.moons?.filter(p => p.id !== focusedBody.id).slice(0, 5) || [];
          recommendationTitle = "NEARBY SYSTEMS";
      }
  }

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-[fadeIn_0.3s_ease-out]">
      <div className="w-full max-w-5xl bg-black border border-cyan-500/30 rounded-2xl overflow-hidden shadow-[0_0_100px_rgba(6,182,212,0.15)] flex flex-col md:flex-row h-[85vh] relative">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.05)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none"></div>

        {/* Left Column: Information */}
        <div className="md:w-5/12 p-8 border-r border-cyan-900/50 flex flex-col relative z-10 bg-black/80 backdrop-blur-md">
            <div className="mb-6 shrink-0">
                <div className="flex items-center space-x-2 mb-2">
                     <Database className="w-4 h-4 text-cyan-500" />
                     <span className="text-cyan-500 font-mono text-xs tracking-widest uppercase">ID: {focusedBody.id.toUpperCase()}</span>
                </div>
                {isSun && (
                    <div className="mb-6 w-32 h-32 rounded-2xl overflow-hidden border-2 border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)] relative group">
                        <img src="profile.jpg" alt="Deekshitth Vegi" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-cyan-900/50 to-transparent pointer-events-none"></div>
                    </div>
                )}
                <div className="flex items-center gap-3">
                    <h2 className="text-4xl font-display font-bold text-white tracking-wide uppercase leading-none">
                        {focusedBody.name}
                    </h2>
                    {/* Add Graduation Cap Icon for University Moons */}
                    {isEducationMoon && (
                        <div className="bg-white/10 p-2 rounded-full border border-white/20">
                            <GraduationCap className="w-6 h-6 text-cyan-300" />
                        </div>
                    )}
                </div>
                
                <div className="flex items-center space-x-2 mt-2 flex-wrap">
                     <span className="bg-cyan-900/50 text-cyan-300 text-[10px] font-bold px-2 py-0.5 rounded border border-cyan-700">TYPE: {focusedBody.type.toUpperCase()}</span>
                     {focusedBody.moons && (
                         <span className="bg-purple-900/50 text-purple-300 text-[10px] font-bold px-2 py-0.5 rounded border border-purple-700">SATELLITES: {focusedBody.moons.length}</span>
                     )}
                     
                     {/* RESUME BUTTON FOR SUN */}
                     {isSun && (
                         <a href="/resume.pdf" download="Deekshitth_Vegi_Resume.pdf" className="flex items-center space-x-1 bg-green-900/50 hover:bg-green-800 text-green-300 hover:text-white text-[10px] font-bold px-2 py-0.5 rounded border border-green-700 transition-colors ml-auto">
                             <FileDown className="w-3 h-3" />
                             <span>DOWNLOAD RESUME</span>
                         </a>
                     )}
                </div>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 space-y-6 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-track]:bg-black/20 [&::-webkit-scrollbar-thumb]:bg-cyan-500/30 [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-cyan-500/60">
                <p className="text-lg text-cyan-100 font-light leading-relaxed border-l-2 border-cyan-600 pl-4">
                    {focusedBody.description}
                </p>

                {focusedBody.moons && focusedBody.moons.length > 0 && (
                    <div className="bg-purple-900/10 p-4 rounded border border-purple-800/50">
                         <h3 className="text-xs font-mono text-purple-400 uppercase mb-3 flex items-center">
                            <Orbit className="w-3 h-3 mr-2" /> DATA FRAGMENTS (SATELLITES)
                        </h3>
                        <p className="text-xs text-gray-400 mb-3">
                            Critical information is stored within the satellite network of this body. Select a satellite to decrypt.
                        </p>
                        <div className="grid grid-cols-2 gap-2">
                            {focusedBody.moons.map(moon => (
                                <button key={moon.id} onClick={() => onNavigate(moon)} className="flex items-center space-x-2 bg-black/40 hover:bg-purple-900/30 p-2 rounded border border-purple-900/30 hover:border-purple-500 transition-all text-left">
                                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: moon.color }}></div>
                                    <span className="text-xs font-mono text-gray-300 hover:text-white">{moon.name}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {focusedBody.about && (
                    <div className="bg-cyan-900/10 p-4 rounded border border-cyan-800/50">
                        <h3 className="text-xs font-mono text-cyan-400 uppercase mb-2 flex items-center"><User className="w-3 h-3 mr-2" /> BIO_LOG</h3>
                        <p className="text-sm text-gray-300 leading-relaxed">{focusedBody.about}</p>
                    </div>
                )}

                <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                     {focusedBody.date && (<div className="bg-cyan-950/30 p-2 rounded border border-cyan-900"><span className="block text-gray-500 mb-1">TIMESTAMP</span><span className="text-cyan-300">{focusedBody.date}</span></div>)}
                     {focusedBody.location && (<div className="bg-cyan-950/30 p-2 rounded border border-cyan-900"><span className="block text-gray-500 mb-1">COORDINATES</span><span className="text-cyan-300">{focusedBody.location}</span></div>)}
                </div>

                {/* UPDATED DETAILS SECTION FOR SOCIAL BUTTONS */}
                {focusedBody.details && focusedBody.details.length > 0 && (
                    <div className="bg-black/40 border border-gray-800 rounded-lg p-4">
                        <h3 className="text-xs font-mono text-gray-500 uppercase mb-3 flex items-center"><Cpu className="w-3 h-3 mr-2" /> Decrypted Data</h3>
                        <ul className="space-y-3">
                            {focusedBody.details.map((detail, i) => {
                                // Check for social links
                                const lower = detail.toLowerCase();
                                let socialButton = null;
                                
                                if (lower.includes('linkedin')) {
                                    const url = detail.split('linkedin.com')[1] ? `https://linkedin.com${detail.split('linkedin.com')[1]}` : '#';
                                    socialButton = (
                                        <a href={url} target="_blank" rel="noreferrer" className="flex items-center w-full bg-blue-900/30 hover:bg-blue-800/50 border border-blue-700/50 p-2 rounded transition-colors text-blue-200 text-sm mt-1">
                                            <Linkedin className="w-4 h-4 mr-2" /> LinkedIn Profile
                                        </a>
                                    );
                                } else if (lower.includes('github')) {
                                    const url = detail.split('github.com')[1] ? `https://github.com${detail.split('github.com')[1]}` : '#';
                                    socialButton = (
                                        <a href={url} target="_blank" rel="noreferrer" className="flex items-center w-full bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600/50 p-2 rounded transition-colors text-gray-200 text-sm mt-1">
                                            <Github className="w-4 h-4 mr-2" /> GitHub Profile
                                        </a>
                                    );
                                } else if (lower.includes('huggingface')) {
                                    const url = detail.split('huggingface.co')[1] ? `https://huggingface.co${detail.split('huggingface.co')[1]}` : '#';
                                    socialButton = (
                                        <a href={url} target="_blank" rel="noreferrer" className="flex items-center w-full bg-yellow-900/30 hover:bg-yellow-800/50 border border-yellow-700/50 p-2 rounded transition-colors text-yellow-200 text-sm mt-1">
                                            <Smile className="w-4 h-4 mr-2" /> Hugging Face Profile
                                        </a>
                                    );
                                }

                                if (socialButton) return <li key={i}>{socialButton}</li>;

                                return (
                                    <li key={i} className="text-sm text-gray-300 flex items-start leading-snug">
                                        <span className="text-cyan-500 mr-2 mt-1">›</span><span>{detail}</span>
                                    </li>
                                );
                            })}
                        </ul>
                    </div>
                )}

                {focusedBody.link && (
                    <a href={focusedBody.link} target="_blank" rel="noreferrer" className="flex items-center justify-center space-x-2 w-full py-3 bg-cyan-900/20 hover:bg-cyan-900/40 border border-cyan-700/50 hover:border-cyan-500 text-cyan-400 rounded transition-all group">
                        <ExternalLink className="w-4 h-4 group-hover:scale-110 transition-transform" />
                        <span className="font-bold text-xs tracking-widest">ACCESS EXTERNAL LINK</span>
                    </a>
                )}
            </div>

            <div className="mt-6 pt-4 border-t border-gray-800 flex justify-between items-center shrink-0">
                 <button onClick={() => onChat(`Tell me more about "${focusedBody.name}"`)} className="flex items-center space-x-2 text-purple-400 hover:text-purple-300 transition-colors text-xs font-mono">
                    <MessageCircleQuestion className="w-4 h-4" /><span>QUERY AI ASSISTANT</span>
                 </button>
                 <div className="text-[10px] text-gray-600 font-mono">SECURE CONNECTION ESTABLISHED</div>
            </div>
        </div>

        {/* Right Column: Visualization */}
        <div className="md:w-7/12 bg-black relative overflow-hidden flex flex-col">
            <div className="absolute top-6 right-6 z-30 flex items-center space-x-3">
                <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors bg-black/50 p-2 rounded-full backdrop-blur-sm border border-gray-800 hover:border-gray-500"><X className="w-6 h-6" /></button>
            </div>
            <div className="absolute top-6 left-6 z-20 pointer-events-none">
                <div className="bg-black/60 backdrop-blur border border-cyan-800/50 px-4 py-2 rounded-full flex items-center shadow-[0_0_15px_rgba(6,182,212,0.1)]">
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse mr-2"></div>
                    <span className="text-xs text-cyan-100 font-mono tracking-wider">LIVE VISUAL FEED</span>
                </div>
            </div>

            <div className="w-full flex-1 cursor-move relative">
                <Canvas camera={{ position: [0, 0, 8], fov: 45 }}>
                    <OrbitControls autoRotate autoRotateSpeed={1} enableZoom={true} minDistance={4} maxDistance={20} />
                    <BodyPreview data={focusedBody} onNavigate={onNavigate} />
                </Canvas>
                {focusedBody.moons && focusedBody.moons.length > 0 && (
                     <div className="absolute bottom-4 left-0 right-0 text-center pointer-events-none">
                         <span className="text-[10px] bg-black/50 text-gray-400 px-2 py-1 rounded border border-white/10 backdrop-blur">CLICK ON SATELLITES TO NAVIGATE</span>
                     </div>
                )}
            </div>

            {/* Bottom Overlay Stats & Recommendations */}
            <div className="bg-black/90 border-t border-gray-800 p-4 flex flex-col space-y-4 z-20">
                <div className="flex justify-between items-center">
                    <div className="flex space-x-8">
                        <div className="space-y-1"><div className="text-[10px] text-gray-500 font-mono uppercase">Object Size</div><div className="text-lg text-white font-display">{focusedBody.size} KM</div></div>
                        <div className="space-y-1"><div className="text-[10px] text-gray-500 font-mono uppercase">Orbit Radius</div><div className="text-lg text-white font-display">{focusedBody.orbitRadius} AU</div></div>
                    </div>
                </div>
                
                {/* NEARBY SYSTEMS BAR / PARENT LINK */}
                <div className="border-t border-gray-800 pt-3 flex items-center justify-between">
                     
                     {/* IF MOON -> SHOW PARENT LINK */}
                     {focusedBody.type === 'moon' && parentBody && (
                         <div className="flex items-center space-x-2 mr-4">
                             <button onClick={() => onNavigate(parentBody)} className="flex items-center space-x-2 bg-yellow-900/30 hover:bg-yellow-900/50 px-3 py-1.5 rounded border border-yellow-700/50 hover:border-yellow-500 transition-all text-yellow-400 group">
                                <ArrowUpLeft className="w-3 h-3 group-hover:-translate-y-0.5 group-hover:-translate-x-0.5 transition-transform" />
                                <span className="text-[10px] font-bold font-mono tracking-widest uppercase">PARENT: {parentBody.name}</span>
                             </button>
                         </div>
                     )}

                     {!isSpecialObject && recommendedItems.length > 0 && (
                         <div className="flex items-center space-x-3 overflow-x-auto [&::-webkit-scrollbar]:h-1.5 [&::-webkit-scrollbar-track]:bg-black/20 [&::-webkit-scrollbar-thumb]:bg-cyan-500/30 [&::-webkit-scrollbar-thumb]:rounded-full pb-2">
                             <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest shrink-0">{recommendationTitle}:</span>
                             {recommendedItems.map(p => (
                                 <button 
                                    key={p.id}
                                    onClick={() => onNavigate(p)}
                                    className="flex items-center space-x-2 bg-gray-900/50 hover:bg-white/10 px-2 py-1 rounded border border-gray-800 hover:border-white/30 transition-all group shrink-0"
                                 >
                                     <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }}></div>
                                     <span className="text-[10px] text-gray-400 group-hover:text-white font-mono uppercase">{p.name}</span>
                                 </button>
                             ))}
                         </div>
                     )}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default HUD;
