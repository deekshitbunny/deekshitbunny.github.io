
import React, { useState } from 'react';
import { SOLAR_SYSTEM_DATA } from '../data';
import { Target, Radio, Globe } from 'lucide-react';

const Radar = () => {
  return (
    <div className="w-48 bg-black/60 backdrop-blur-md border border-cyan-800/50 rounded-lg overflow-hidden flex flex-col">
        <div className="bg-cyan-950/50 p-2 border-b border-cyan-800 flex items-center justify-between">
            <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase">Navigation</span>
            <Radio className="w-3 h-3 text-cyan-500 animate-pulse" />
        </div>
        
        <div className="p-2 space-y-1 max-h-40 overflow-y-auto scrollbar-hide">
             {/* List nearby targets (Simulated list) */}
             <div className="flex items-center justify-between text-xs p-1 hover:bg-white/5 rounded cursor-pointer group">
                 <div className="flex items-center text-yellow-500">
                    <Globe className="w-3 h-3 mr-2" />
                    <span className="font-display">SUN (About)</span>
                 </div>
                 <span className="font-mono text-gray-500 text-[9px]">0.0 AU</span>
             </div>
             
             {SOLAR_SYSTEM_DATA.moons?.map(planet => (
                 <div key={planet.id} className="flex items-center justify-between text-xs p-1 hover:bg-white/5 rounded cursor-pointer group">
                     <div className="flex items-center text-cyan-300 group-hover:text-white transition-colors">
                        <Target className="w-3 h-3 mr-2 opacity-50" />
                        <span>{planet.name}</span>
                     </div>
                     <span className="font-mono text-gray-500 text-[9px]">{planet.orbitRadius} AU</span>
                 </div>
             ))}
        </div>
        
        <div className="h-1 bg-cyan-900/50 w-full relative overflow-hidden">
             <div className="absolute inset-y-0 left-0 bg-cyan-500 w-1/3 animate-[loading_2s_linear_infinite]"></div>
        </div>
    </div>
  );
};

export default Radar;