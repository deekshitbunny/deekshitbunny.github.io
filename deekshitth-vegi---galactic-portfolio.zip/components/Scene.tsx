
import React, { useRef, useEffect, useState, useMemo, useLayoutEffect, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { CameraControls, Trail, useGLTF, Html } from '@react-three/drei';
import * as THREE from 'three';
import { Vector3, MathUtils, Euler, AdditiveBlending, InstancedMesh, Color, Group, DoubleSide } from 'three';
import CelestialBody from './CelestialBody';
import { SOLAR_SYSTEM_DATA, AUTHOR_AGE, STAR_SYSTEM_TYPES } from '../data';
import { CelestialBodyData } from '../types';
import { soundManager } from '../utils/SoundManager';
import { Crosshair } from 'lucide-react';

interface SceneProps {
  focusedBody: CelestialBodyData | null;
  setFocusedBody: (body: CelestialBodyData | null) => void;
  viewMode: 'orbit' | 'spaceship';
  onDeath?: (reason?: 'collision' | 'blackhole') => void;
  isDead?: boolean;
  onReward?: (name: string, description: string) => void;
  mouseSensitivity?: number;
  mobileInputRef?: React.MutableRefObject<{ x: number, y: number, lookX: number, lookY: number }>;
  onScore?: () => void;
  onSystemClick?: (name: string) => void;
  launchState?: 'idle' | 'traveling' | 'countdown' | 'flying' | 'animating';
  onLaunchComplete?: () => void;
  score?: number;
  onSpeedChange?: (speed: number) => void;
}

// CONSTANT TO SCALE DOWN THE UNIVERSE FOR NUMERICAL STABILITY
// 0.002 makes everything 500x smaller mathematically than original, eliminating floating point jitter.
const UNIVERSE_SCALE = 0.002;

// SOFT GLOW TEXTURE
const getCircleTexture = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 128; 
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
        ctx.clearRect(0, 0, 128, 128);
        const gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
        gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
        gradient.addColorStop(0.1, 'rgba(255, 255, 255, 0.6)');
        gradient.addColorStop(0.3, 'rgba(255, 255, 255, 0.15)');
        gradient.addColorStop(0.7, 'rgba(255, 255, 255, 0.02)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 128, 128);
    }
    return new THREE.CanvasTexture(canvas);
};

const ProceduralBlackHoleVisuals = ({ radius }: { radius: number }) => {
    const diskRef = useRef<THREE.Group>(null);
    useFrame((state, delta) => {
        if (diskRef.current) diskRef.current.rotation.z -= delta * 0.15;
    });

    return (
        <group>
             <mesh><sphereGeometry args={[radius, 64, 64]} /><meshBasicMaterial color="#000000" /></mesh>
             <mesh><sphereGeometry args={[radius * 1.05, 64, 64]} /><meshBasicMaterial color="#ffaa00" transparent opacity={0.3} side={THREE.BackSide} blending={AdditiveBlending} /></mesh>
             <group ref={diskRef} rotation={[-Math.PI / 2, 0, 0]}>
                 <mesh><ringGeometry args={[radius * 1.5, radius * 5, 128]} /><meshBasicMaterial color="#ff6600" side={DoubleSide} transparent opacity={0.6} blending={AdditiveBlending} depthWrite={false} /></mesh>
                 <mesh position={[0,0,10]}><ringGeometry args={[radius * 1.2, radius * 2.5, 128]} /><meshBasicMaterial color="#ffffff" side={DoubleSide} transparent opacity={0.4} blending={AdditiveBlending} depthWrite={false} /></mesh>
             </group>
             <sprite scale={[radius * 15, radius * 15, 1]}>
                 <spriteMaterial map={useMemo(() => getCircleTexture(), [])} color="#ff4400" transparent opacity={0.2} blending={AdditiveBlending} depthWrite={false} />
             </sprite>
        </group>
    );
};

const MassiveGalaxy = ({ radius }: { radius: number }) => {
    const pointsRef = useRef<THREE.Points>(null);
    const geometry = useMemo(() => {
        const count = 120000;
        const positions = new Float32Array(count * 3);
        const colors = new Float32Array(count * 3);
        const sizes = new Float32Array(count);
        const opacityAttrs = new Float32Array(count); 
        const centerColor = new Color("#FFD700"); 
        const midColor = new Color("#FFFFFF");    
        const outerColor = new Color("#40C4FF");  

        for(let i=0; i<count; i++) {
            const arms = 3 + Math.floor(Math.random() * 3); 
            const armIndex = i % arms;
            const dist = Math.pow(Math.random(), 1.5); 
            const r = dist * radius;
            const angleNoise = (Math.random() - 0.5) * 3.0; 
            const angle = (armIndex / arms) * Math.PI * 2 + (dist * 12.0) + angleNoise;
            const spread = r * 0.6; 
            const x = Math.cos(angle) * r + (Math.random() - 0.5) * spread;
            const z = Math.sin(angle) * r + (Math.random() - 0.5) * spread;
            const u1 = Math.random();
            const u2 = Math.random();
            const randStdNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
            const stdDev = (radius * 0.05) * (1 - dist * 0.6); 
            const y = randStdNormal * stdDev;

            positions[i*3] = x;
            positions[i*3+1] = y;
            positions[i*3+2] = z;

            const mixDist = Math.max(0, Math.min(1, dist + (Math.random() - 0.5) * 0.2));
            const c = new Color();
            if (mixDist < 0.2) c.lerpColors(centerColor, midColor, mixDist / 0.2);
            else if (mixDist < 0.6) c.copy(midColor);
            else c.lerpColors(midColor, outerColor, (mixDist - 0.6) / 0.4);

            colors[i*3] = c.r;
            colors[i*3+1] = c.g;
            colors[i*3+2] = c.b;
            sizes[i] = (Math.random() * 3000 + 200) * (1.2 - dist); 
            opacityAttrs[i] = 1.0 - Math.pow(dist, 4); 
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        geo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
        geo.setAttribute('opacityAttr', new THREE.BufferAttribute(opacityAttrs, 1));
        return geo;
    }, [radius]);

    useFrame((state, delta) => {
        if (pointsRef.current) pointsRef.current.rotation.y -= delta * 0.001; 
    });

    return (
        <points ref={pointsRef} geometry={geometry}> 
             <shaderMaterial 
                transparent vertexColors blending={AdditiveBlending} depthWrite={false}
                vertexShader={`
                    attribute float size; attribute float opacityAttr; varying vec3 vColor; varying float vOpacity;
                    void main() {
                        vColor = color; vOpacity = opacityAttr;
                        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                        gl_Position = projectionMatrix * mvPosition;
                        // ADJUSTED POINT SIZE LOGIC FOR SCALED UNIVERSE
                        // Constant 1000.0 scaled down by UNIVERSE_SCALE to keep dots crisp
                        gl_PointSize = size * (${(1000.0 * UNIVERSE_SCALE).toFixed(4)} / -mvPosition.z); 
                        gl_PointSize = min(gl_PointSize, 50.0); gl_PointSize = max(gl_PointSize, 2.0);
                        gl_Position = projectionMatrix * mvPosition;
                    }
                `}
                fragmentShader={`
                    varying vec3 vColor; varying float vOpacity;
                    void main() {
                        vec2 coord = gl_PointCoord - vec2(0.5);
                        float dist = length(coord);
                        if (dist > 0.5) discard;
                        float alpha = 1.0 - smoothstep(0.1, 0.5, dist);
                        gl_FragColor = vec4(vColor, alpha * vOpacity * 0.8);
                    }
                `}
             />
        </points>
    );
};

const BlackHoleModel = ({ radius }: { radius: number }) => {
    const { scene } = useGLTF('/models/blackhole.glb');
    return <primitive object={scene} scale={[radius/2, radius/2, radius/2]} />;
};

class ModelErrorBoundary extends React.Component<{ fallback: React.ReactNode, children: React.ReactNode }, { hasError: boolean }> {
    state = { hasError: false };
    constructor(props: any) { super(props); this.state = { hasError: false }; }
    static getDerivedStateFromError(error: any) { return { hasError: true }; }
    componentDidCatch(error: any, errorInfo: any) { console.warn("Failed to load 3D model, reverting to fallback:", error); }
    render() { if (this.state.hasError) return this.props.fallback; return this.props.children; }
}

const BlackHole = ({ position, onClick, onDeath, viewMode, registerRef, isDead }: { position: [number, number, number], onClick: () => void, onDeath?: (reason: 'collision' | 'blackhole') => void, viewMode: 'orbit' | 'spaceship', registerRef?: (id: string, group: Group) => void, isDead?: boolean }) => {
    const meshRef = useRef<THREE.Group>(null);
    const { camera } = useThree();
    const [modelExists, setModelExists] = useState<boolean | null>(false); 

    useEffect(() => { if (registerRef && meshRef.current) registerRef('blackhole', meshRef.current); }, [registerRef]);
    useEffect(() => { fetch('/models/blackhole.glb', { method: 'HEAD' }).then((res) => { if (res.ok) setModelExists(true); }).catch(() => {}); }, []);
    
    // Scaled Black Hole Metrics
    const EVENT_HORIZON_RADIUS = 50000 * UNIVERSE_SCALE; 
    const GRAVITY_WELL_RADIUS = 200000 * UNIVERSE_SCALE; 

    useFrame((state, delta) => {
        if (meshRef.current) meshRef.current.rotation.y += delta * 0.005;
        // IMPORTANT: STOP GRAVITY LOGIC IF ALREADY DEAD to prevent respawn loop
        if (viewMode === 'spaceship' && !isDead) {
            const worldPos = new Vector3();
            meshRef.current?.getWorldPosition(worldPos);
            const dist = camera.position.distanceTo(worldPos);
            if (dist < GRAVITY_WELL_RADIUS) {
                const factor = 1 - (dist / GRAVITY_WELL_RADIUS); 
                // Scaled Pull Strength
                const pullStrength = (100 + (Math.pow(factor, 3) * 10000)) * UNIVERSE_SCALE; 
                const direction = new Vector3().subVectors(worldPos, camera.position).normalize();
                camera.position.addScaledVector(direction, pullStrength * delta);
                if (factor > 0.1) {
                    const turbulence = factor * 400 * UNIVERSE_SCALE;
                    camera.position.x += (Math.random() - 0.5) * turbulence * delta;
                    camera.position.y += (Math.random() - 0.5) * turbulence * delta;
                    camera.rotation.z += (Math.random() - 0.5) * factor * delta * 8;
                }
                const fovDistortion = MathUtils.mapLinear(dist, GRAVITY_WELL_RADIUS, EVENT_HORIZON_RADIUS, 60, 170);
                if (camera instanceof THREE.PerspectiveCamera) {
                    camera.fov = MathUtils.lerp(camera.fov, fovDistortion, delta * 3);
                    camera.updateProjectionMatrix();
                }
                if (dist < EVENT_HORIZON_RADIUS + (5000 * UNIVERSE_SCALE)) if (onDeath) onDeath('blackhole');
            } else {
                 if (camera instanceof THREE.PerspectiveCamera && camera.fov > 60.1) {
                    camera.fov = MathUtils.lerp(camera.fov, 60, delta);
                    camera.updateProjectionMatrix();
                }
            }
        }
    });

    return (
        <group position={position} ref={meshRef} onClick={(e) => { e.stopPropagation(); onClick(); }} onPointerOver={() => document.body.style.cursor = 'pointer'} onPointerOut={() => document.body.style.cursor = 'auto'}>
             {modelExists === true ? (
                 <ModelErrorBoundary fallback={<ProceduralBlackHoleVisuals radius={EVENT_HORIZON_RADIUS} />}>
                     <Suspense fallback={<ProceduralBlackHoleVisuals radius={EVENT_HORIZON_RADIUS} />}>
                        <BlackHoleModel radius={EVENT_HORIZON_RADIUS} />
                     </Suspense>
                 </ModelErrorBoundary>
             ) : ( <ProceduralBlackHoleVisuals radius={EVENT_HORIZON_RADIUS} /> )}
             {/* Scaled Galaxy Radius */}
             <MassiveGalaxy radius={10000000 * UNIVERSE_SCALE} /> 
        </group>
    )
}

const ProceduralPlanets = ({ starScale, starColor }: { starScale: number, starColor: string }) => {
    const count = 1 + Math.floor(Math.random() * 4); 
    const planets = useMemo(() => new Array(count).fill(0).map(() => ({
        radius: starScale * (0.8 + Math.random() * 2.0),
        speed: (Math.random() * 0.5 + 0.1) * (Math.random() > 0.5 ? 1 : -1),
        size: starScale * (0.05 + Math.random() * 0.15),
        color: new Color().setHSL(Math.random(), 0.6, 0.5),
        offset: Math.random() * Math.PI * 2
    })), [count, starScale]);
    const groupRefs = useRef<THREE.Group[]>([]);
    
    useFrame((state, delta) => {
        // CLAMP DELTA TO PREVENT TWITCHING
        const dt = Math.min(delta, 0.1);
        planets.forEach((p, i) => { if (groupRefs.current[i]) groupRefs.current[i].rotation.y += p.speed * dt; });
    });

    return (
        <group>
            {planets.map((p, i) => (
                <group key={i} ref={el => { if (el) groupRefs.current[i] = el; }}>
                    <mesh position={[p.radius, 0, 0]}><sphereGeometry args={[p.size, 16, 16]} /><meshStandardMaterial color={p.color} roughness={0.7} /></mesh>
                    <mesh rotation={[-Math.PI/2, 0, 0]}><ringGeometry args={[p.radius, p.radius + p.radius * 0.005, 128]} /><meshBasicMaterial color={starColor} transparent opacity={0.2} side={DoubleSide} /></mesh>
                </group>
            ))}
        </group>
    )
};

const AlienSolarSystem = ({ position, centerOfOrbit, orbitRadius, speed, color, name, onClick, scale = 1, inclination = 0, starType = 'single', registerRef, id }: { position: [number, number, number], centerOfOrbit: Vector3, orbitRadius: number, speed: number, color: string, name: string, onClick: (n: string) => void, scale?: number, inclination?: number, starType?: 'single' | 'binary' | 'trinary', registerRef?: (id: string, group: Group) => void, id?: string }) => {
    const groupRef = useRef<THREE.Group>(null);
    const starVisualsRef = useRef<THREE.Group>(null);
    const [hovered, setHover] = useState(false);
    const angleRef = useRef(Math.random() * Math.PI * 2);
    const texture = useMemo(() => getCircleTexture(), []);
    
    // SCALE VISUALS
    const VISUAL_SCALE = 80000 * scale * UNIVERSE_SCALE; 

    useEffect(() => { if (registerRef && groupRef.current && id) registerRef(id, groupRef.current); }, [registerRef, id]);

    useFrame((state, delta) => {
        // CLAMP DELTA TO PREVENT TWITCHING
        const dt = Math.min(delta, 0.1);

        if (groupRef.current) {
            angleRef.current += speed * dt;
            const x = Math.cos(angleRef.current) * orbitRadius;
            const z = Math.sin(angleRef.current) * orbitRadius;
            const y = Math.sin(angleRef.current) * (orbitRadius * Math.sin(inclination)); 
            groupRef.current.position.set(x, y, z);
            groupRef.current.rotation.y += dt * 0.2;
        }
        if (starVisualsRef.current) {
            if (starType === 'binary') starVisualsRef.current.rotation.y += dt * 0.5; 
            if (starType === 'trinary') starVisualsRef.current.rotation.y += dt * 0.2; 
        }
    });

    const StarCore = () => {
        if (starType === 'binary') {
            return (
                <group ref={starVisualsRef}>
                    <group position={[VISUAL_SCALE * 0.15, 0, 0]}>
                        <mesh><sphereGeometry args={[VISUAL_SCALE * 0.05, 32, 32]} /><meshBasicMaterial color={color} /></mesh>
                        <sprite scale={[VISUAL_SCALE, VISUAL_SCALE, 1]}><spriteMaterial map={texture} color={color} transparent opacity={0.6} blending={AdditiveBlending} depthWrite={false}/></sprite>
                    </group>
                    <group position={[-VISUAL_SCALE * 0.15, 0, 0]}>
                        <mesh><sphereGeometry args={[VISUAL_SCALE * 0.04, 32, 32]} /><meshBasicMaterial color="#ffffff" /></mesh>
                        <sprite scale={[VISUAL_SCALE * 0.8, VISUAL_SCALE * 0.8, 1]}><spriteMaterial map={texture} color="#aaddff" transparent opacity={0.6} blending={AdditiveBlending} depthWrite={false}/></sprite>
                    </group>
                    <ProceduralPlanets starScale={VISUAL_SCALE * 0.2} starColor={color} />
                </group>
            )
        }
        if (starType === 'trinary') {
             return (
                <group ref={starVisualsRef}>
                    <group position={[0,0,0]} rotation={[0,0,Math.PI/4]}>
                         <group position={[VISUAL_SCALE * 0.08, 0, 0]}>
                            <mesh><sphereGeometry args={[VISUAL_SCALE*0.04, 32, 32]} /><meshBasicMaterial color={color} /></mesh>
                            <sprite scale={[VISUAL_SCALE * 0.6, VISUAL_SCALE * 0.6, 1]}><spriteMaterial map={texture} color={color} transparent opacity={0.6} blending={AdditiveBlending} depthWrite={false}/></sprite>
                         </group>
                         <group position={[-VISUAL_SCALE * 0.08, 0, 0]}>
                            <mesh><sphereGeometry args={[VISUAL_SCALE*0.035, 32, 32]} /><meshBasicMaterial color="#ff5500" /></mesh>
                            <sprite scale={[VISUAL_SCALE * 0.5, VISUAL_SCALE * 0.5, 1]}><spriteMaterial map={texture} color="#ff5500" transparent opacity={0.6} blending={AdditiveBlending} depthWrite={false}/></sprite>
                         </group>
                    </group>
                    <group position={[0, 0, VISUAL_SCALE * 0.35]}>
                        <mesh><sphereGeometry args={[VISUAL_SCALE*0.05, 32, 32]} /><meshBasicMaterial color="#ffaa00" /></mesh>
                        <sprite scale={[VISUAL_SCALE * 0.7, VISUAL_SCALE * 0.7, 1]}><spriteMaterial map={texture} color="#ffaa00" transparent opacity={0.6} blending={AdditiveBlending} depthWrite={false}/></sprite>
                    </group>
                    <ProceduralPlanets starScale={VISUAL_SCALE * 0.3} starColor={color} />
                </group>
            )
        }
        return (
            <group>
                <mesh><sphereGeometry args={[VISUAL_SCALE * 0.06, 32, 32]} /><meshBasicMaterial color={color} /></mesh>
                <sprite scale={[VISUAL_SCALE, VISUAL_SCALE, 1]}><spriteMaterial map={texture} color={color} transparent opacity={hovered ? 0.8 : 0.6} blending={AdditiveBlending} depthWrite={false} /></sprite>
                <ProceduralPlanets starScale={VISUAL_SCALE * 0.1} starColor={color} />
            </group>
        )
    };

    return (
        <group ref={groupRef} position={position} onClick={(e) => { e.stopPropagation(); onClick(name); }} onPointerOver={() => { document.body.style.cursor = 'pointer'; setHover(true); }} onPointerOut={() => { document.body.style.cursor = 'auto'; setHover(false); }}>
            <mesh visible={false}><sphereGeometry args={[VISUAL_SCALE * 0.5, 16, 16]} /></mesh>
            <StarCore />
        </group>
    );
}

const RogueSystems = ({ setFocusedBody, onDeath, viewMode, registerRef }: { setFocusedBody: (data: CelestialBodyData) => void, onDeath?: () => void, viewMode: 'orbit' | 'spaceship', registerRef?: (id: string, group: Group) => void }) => {
    const GALAXY_CENTER = new Vector3(0, 0, 0); 
    const systems = useMemo(() => {
        const arr = [];
        const count = AUTHOR_AGE; 
        for(let i=0; i<count; i++) {
             // BOUNDARY FIX: Increased minimum distance to 2,000,000 (scaled)
             // This prevents them from generating near the main solar system (which is at 0,0,0)
             const distance = (2000000 + Math.random() * 8000000) * UNIVERSE_SCALE;
             
             const distRatio = Math.min(1.0, distance / (10000000 * UNIVERSE_SCALE));
             const baseScale = 2.0 + (distRatio * Math.random() * 5.0);
             // ADJUST SPEED for scaled distance to keep orbit time roughly similar
             const speed = (10000 / Math.sqrt(distance / UNIVERSE_SCALE)) * (0.0002 + Math.random() * 0.0002);
             const hue = Math.random();
             const color = new Color().setHSL(hue, 1, 0.6).getStyle();
             const id = `rogue-${i}`;
             const inclination = (Math.random() - 0.5) * 0.05; 
             let starType = STAR_SYSTEM_TYPES[i] || 'single';
             const prefix = ['Kepler', 'Gliese', 'Trappist', 'Proxima', 'Cygnus', 'Vela', 'Orion'];
             const suffix = Math.floor(Math.random() * 9000) + 1000;
             const name = `${prefix[Math.floor(Math.random()*prefix.length)]}-${suffix}`;
             arr.push({ distance, speed, color, scale: baseScale, id, name, inclination, starType });
        }
        return arr;
    }, []);

    const handleClick = (sys: any) => {
        setFocusedBody({
            id: sys.id,
            type: 'planet', 
            name: sys.name,
            description: `Uncharted ${sys.starType.charAt(0).toUpperCase() + sys.starType.slice(1)} System`,
            about: `A distant star system located ${(sys.distance / (149600000 * UNIVERSE_SCALE)).toFixed(2)} AU from the galactic core.`,
            color: sys.color,
            size: sys.scale * 4000,
            orbitRadius: sys.distance,
            orbitSpeed: sys.speed,
            details: [
                `Star Classification: Class ${['M', 'K', 'G', 'F'][Math.floor(Math.random()*4)]}`, 
                `Mass: ${(sys.scale * 0.5).toFixed(2)} Solar Masses`,
                `Planetary Bodies: ${Math.floor(Math.random() * 5) + 1} Detected`,
            ]
        });
    };

    return (
        <group>
            {systems.map((sys) => (
                <AlienSolarSystem key={sys.id} id={sys.id} position={[0,0,0]} centerOfOrbit={GALAXY_CENTER} orbitRadius={sys.distance} speed={sys.speed} color={sys.color} name={sys.name} onClick={() => handleClick(sys)} scale={sys.scale} inclination={sys.inclination} starType={sys.starType as any} registerRef={registerRef} />
            ))}
        </group>
    )
}

const GalacticHazards = ({ shipPosition, onDeath, active }: { shipPosition: React.MutableRefObject<Vector3>, onDeath?: () => void, active: boolean }) => {
    const meshRef = useRef<InstancedMesh>(null);
    const count = 5000; 
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const groupRef = useRef<Group>(null);
    const hazards = useMemo(() => new Array(count).fill(0).map(() => ({
        // SCALE HAZARDS
        distance: (600000 + Math.random() * 10000000) * UNIVERSE_SCALE, 
        angle: Math.random() * Math.PI * 2,
        speed: (50000 / (600000 + Math.random() * 10000000 + 1)) * (0.005 + Math.random() * 0.01),
        size: (400 + Math.random() * 1200) * UNIVERSE_SCALE, 
        yOffset: ((Math.random() - 0.5) * 20000) * UNIVERSE_SCALE
    })), []);

    useFrame((state, delta) => {
        if (!meshRef.current) return;
        hazards.forEach((h, i) => {
            h.angle += h.speed * delta;
            tempObject.position.set(Math.cos(h.angle) * h.distance, h.yOffset, Math.sin(h.angle) * h.distance);
            tempObject.scale.set(h.size, h.size, h.size);
            tempObject.rotation.x += delta * 0.1;
            tempObject.updateMatrix();
            meshRef.current!.setMatrixAt(i, tempObject.matrix);
        });
        meshRef.current.instanceMatrix.needsUpdate = true;
    });

    return (
        <group ref={groupRef}>
            <instancedMesh ref={meshRef} args={[undefined, undefined, hazards.length]}>
                <dodecahedronGeometry args={[1, 1]} />
                <meshStandardMaterial color="#050505" roughness={0.9} metalness={0.1} />
            </instancedMesh>
        </group>
    );
};

const UniverseStars = () => {
    const texture = useMemo(() => getCircleTexture(), []);
    const points = useMemo(() => {
        const count = 80000; 
        const positions = new Float32Array(count * 3);
        // SCALED STAR FIELD
        const minRadius = 10000 * UNIVERSE_SCALE; const maxRadius = 300000000 * UNIVERSE_SCALE; 
        const solarSystemExclusionRadius = 200000 * UNIVERSE_SCALE; 
        let pIndex = 0; const tempVec = new THREE.Vector3();
        while (pIndex < count) {
             const u = Math.random(); const v = Math.random();
             const theta = 2 * Math.PI * u; const phi = Math.acos(2 * v - 1);
             const r = minRadius + (maxRadius - minRadius) * Math.pow(Math.random(), 1/3); 
             const x = r * Math.sin(phi) * Math.cos(theta);
             const y = r * Math.sin(phi) * Math.sin(theta);
             const z = r * Math.cos(phi);
             tempVec.set(x, y, z);
             if (tempVec.length() > solarSystemExclusionRadius) {
                 positions[pIndex*3] = x; positions[pIndex*3+1] = y; positions[pIndex*3+2] = z;
                 pIndex++;
             }
        }
        return positions;
    }, []);

    return (
        <points>
            <bufferGeometry><bufferAttribute attach="attributes-position" count={points.length/3} array={points} itemSize={3} /></bufferGeometry>
            <shaderMaterial transparent blending={AdditiveBlending} depthWrite={false} uniforms={{ textureMap: { value: texture }, color: { value: new THREE.Color(0xffffff) } }} vertexShader={`attribute float size; void main() { vec4 mvPosition = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mvPosition; gl_PointSize = 15000.0 * (1.0 / -mvPosition.z); gl_PointSize = max(gl_PointSize, 3.0); gl_PointSize = min(gl_PointSize, 8.0); }`} fragmentShader={`uniform vec3 color; uniform sampler2D textureMap; void main() { vec4 texColor = texture2D(textureMap, gl_PointCoord); if (texColor.a < 0.1) discard; gl_FragColor = vec4(color, texColor.a); }`} />
        </points>
    );
}

const ShipLights = ({ defaultOn = false }: { defaultOn?: boolean }) => {
    const [on, setOn] = useState(defaultOn);
    const { camera, scene } = useThree();
    const lightRef = useRef<THREE.SpotLight>(null);
    const targetRef = useRef<THREE.Object3D>(new THREE.Object3D());

    useEffect(() => { scene.add(targetRef.current); return () => { scene.remove(targetRef.current); }; }, [scene]);
    useEffect(() => {
        const handler = (e: KeyboardEvent) => { if(e.key.toLowerCase() === 'f') { setOn(p => !p); soundManager.playLaser(); } };
        window.addEventListener('keydown', handler); return () => window.removeEventListener('keydown', handler);
    }, []);

    useFrame(() => {
        if (lightRef.current) {
            lightRef.current.position.copy(camera.position);
            const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
            targetRef.current.position.copy(camera.position).add(forward.multiplyScalar(5000 * UNIVERSE_SCALE)); 
            lightRef.current.target = targetRef.current;
            lightRef.current.updateMatrixWorld();
        }
    });

    return (
        <spotLight 
            ref={lightRef} 
            intensity={8000000 * UNIVERSE_SCALE} 
            distance={500000 * UNIVERSE_SCALE} 
            angle={1.5} 
            penumbra={0.4} 
            color="#e6f0ff" 
            castShadow 
            visible={on} 
        />
    );
}

type AsteroidData = { position: Vector3, scale: number, scales: [number, number, number], rotation: [number, number, number], destroyed: boolean, rotationSpeed: [number, number, number], orbitRadius: number, orbitAngle: number, orbitSpeed: number, orbitY: number };

const ExplosionSystem = React.forwardRef((props, ref: React.MutableRefObject<any>) => {
    const count = 500; // Increased count
    const meshRef = useRef<InstancedMesh>(null);
    const dummy = useMemo(() => new THREE.Object3D(), []);
    const particles = useRef<{ pos: Vector3, vel: Vector3, age: number, active: boolean, colorScale: number }[]>([]);
    const colors = [new Color("#ffaa00"), new Color("#ff4400"), new Color("#ffffff")];

    useLayoutEffect(() => {
        for(let i=0; i<count; i++) particles.current.push({ pos: new Vector3(), vel: new Vector3(), age: 0, active: false, colorScale: 1 });
        if (meshRef.current) { dummy.scale.set(0,0,0); dummy.updateMatrix(); for(let i=0; i<count; i++) meshRef.current.setMatrixAt(i, dummy.matrix); meshRef.current.instanceMatrix.needsUpdate = true; }
    }, []);

    useLayoutEffect(() => {
        if(ref) {
            ref.current = {
                explode: (position: Vector3, scale: number = 1) => {
                    let spawned = 0;
                    for(let i=0; i<particles.current.length; i++) {
                        if(!particles.current[i].active && spawned < 30 * scale) { // Increased particles per explosion
                            particles.current[i].active = true;
                            particles.current[i].pos.copy(position);
                            // SCALE PARTICLE VELOCITY
                            particles.current[i].vel.set((Math.random() - 0.5) * 150 * scale * UNIVERSE_SCALE, (Math.random() - 0.5) * 150 * scale * UNIVERSE_SCALE, (Math.random() - 0.5) * 150 * scale * UNIVERSE_SCALE);
                            particles.current[i].age = 1.0; 
                            particles.current[i].colorScale = Math.random();
                            spawned++;
                        }
                    }
                }
            }
        }
    }, [ref]);

    useFrame((state, delta) => {
        if(!meshRef.current) return;
        particles.current.forEach((p, i) => {
            if(p.active) {
                p.pos.addScaledVector(p.vel, delta * 5);
                p.age -= delta * 1.5; 
                if(p.age <= 0) p.active = false;
                dummy.position.copy(p.pos);
                // SCALE EXPLOSION SIZE - SIGNIFICANTLY INCREASED FOR VISIBILITY
                const scale = (p.age > 0.8 ? p.age * 1.5 : p.age) * 60 * UNIVERSE_SCALE; 
                dummy.scale.set(scale, scale, scale);
                dummy.updateMatrix();
                meshRef.current!.setMatrixAt(i, dummy.matrix);
                meshRef.current!.setColorAt(i, colors[Math.floor(p.colorScale * colors.length)]);
            } else {
                dummy.scale.set(0,0,0);
                dummy.updateMatrix();
                meshRef.current!.setMatrixAt(i, dummy.matrix);
            }
        });
        meshRef.current.instanceMatrix.needsUpdate = true;
        if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
    });

    return (
        <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
            <dodecahedronGeometry args={[1, 0]} />
            <meshBasicMaterial color="#ffffff" transparent opacity={0.8} depthWrite={false} vertexColors toneMapped={false} />
        </instancedMesh>
    )
});

const AsteroidField = ({ shipPosition, onCollision, gracePeriod, asteroidDataRef, viewMode }: { shipPosition: React.MutableRefObject<Vector3>, onCollision: () => void, gracePeriod: boolean, asteroidDataRef: React.MutableRefObject<AsteroidData[]>, viewMode: 'orbit' | 'spaceship' }) => {
    const meshRef = useRef<THREE.InstancedMesh>(null);
    const count = 3000; 
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    
    // RESTORED CUSTOM SHADER for Sun-Facing Glow
    const asteroidMaterial = useMemo(() => {
        const mat = new THREE.MeshStandardMaterial({
            color: "#050505", 
            roughness: 0.9,
            metalness: 0.1
        });
        
        mat.onBeforeCompile = (shader) => {
            shader.vertexShader = `
                varying vec3 vWorldPos;
                varying vec3 vSunDirView;
                ${shader.vertexShader}
            `;
            shader.vertexShader = shader.vertexShader.replace(
                '#include <worldpos_vertex>',
                `
                #include <worldpos_vertex>
                vWorldPos = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz;
                vec3 sunDirWorld = normalize(-vWorldPos); 
                vSunDirView = (viewMatrix * vec4(sunDirWorld, 0.0)).xyz;
                `
            );

            shader.fragmentShader = `
                varying vec3 vWorldPos;
                varying vec3 vSunDirView;
                ${shader.fragmentShader}
            `;
            shader.fragmentShader = shader.fragmentShader.replace(
                '#include <emissivemap_fragment>',
                `
                #include <emissivemap_fragment>
                vec3 sunDir = normalize(vSunDirView);
                vec3 asteroidNormal = normalize(vNormal);
                float sunFace = dot(asteroidNormal, sunDir);
                if (sunFace < 0.1) sunFace = 0.0;
                float intensity = smoothstep(0.1, 1.0, sunFace);
                float dist = length(vWorldPos);
                // ADJUSTED DISTANCE FACTOR FOR SCALED UNIVERSE
                float distFactor = ${(15000.0 * UNIVERSE_SCALE).toFixed(4)} / (${(10000.0 * UNIVERSE_SCALE).toFixed(4)} + dist); 
                vec3 glowColor = vec3(1.0, 0.7, 0.5); 
                totalEmissiveRadiance += glowColor * intensity * distFactor * 1.5;
                `
            );
        };
        return mat;
    }, []);

    useMemo(() => {
        const temp: AsteroidData[] = [];
        let attempts = 0;
        while (temp.length < count && attempts < 15000) {
            attempts++;
            const angle = Math.random() * Math.PI * 2;
            // SCALED ASTEROID ORBITS
            const radius = (14000 + Math.random() * 50000) * UNIVERSE_SCALE;
            const y = ((Math.random() - 0.5) * 6000) * UNIVERSE_SCALE; 
            const pos = new Vector3(Math.cos(angle) * radius, y, Math.sin(angle) * radius);
            
            const distFromCenter = Math.sqrt(pos.x * pos.x + pos.z * pos.z);
            let safe = true;
            // Scale exclusion zone
            SOLAR_SYSTEM_DATA.moons?.forEach(planet => { if (Math.abs(distFromCenter - (planet.orbitRadius * UNIVERSE_SCALE)) < (planet.size * UNIVERSE_SCALE * 2 + (1000 * UNIVERSE_SCALE))) safe = false; });

            if (safe) {
                // SCALED ASTEROID SIZES
                const scale = (35 + Math.random() * 60) * UNIVERSE_SCALE; 
                const baseSpeed = (400 * UNIVERSE_SCALE) / radius; 
                temp.push({ 
                    position: pos, scale, scales: [1+Math.random()*0.5, 1+Math.random()*0.5, 1+Math.random()*0.5],
                    rotation: [Math.random()*Math.PI, Math.random()*Math.PI, Math.random()*Math.PI], destroyed: false,
                    rotationSpeed: [(Math.random()-0.5)*0.5, (Math.random()-0.5)*0.5, (Math.random()-0.5)*0.5],
                    orbitRadius: radius, orbitAngle: angle, orbitY: y, orbitSpeed: baseSpeed * (0.8 + Math.random() * 0.4) * (Math.random() > 0.5 ? 1 : -1) * 0.5
                });
            }
        }
        asteroidDataRef.current = temp;
    }, []);

    useFrame((state, delta) => {
        if (!meshRef.current) return;
        asteroidDataRef.current.forEach((data, i) => {
            if (data.destroyed) { tempObject.scale.set(0, 0, 0); } else {
                data.orbitAngle += data.orbitSpeed * delta;
                data.position.set(Math.cos(data.orbitAngle) * data.orbitRadius, data.orbitY, Math.sin(data.orbitAngle) * data.orbitRadius * 0.9);
                tempObject.position.copy(data.position);
                data.rotation[0] += data.rotationSpeed[0] * delta;
                tempObject.rotation.set(data.rotation[0], data.rotation[1], data.rotation[2]);
                tempObject.scale.set(data.scale*data.scales[0], data.scale*data.scales[1], data.scale*data.scales[2]);
            }
            tempObject.updateMatrix();
            meshRef.current!.setMatrixAt(i, tempObject.matrix);
        });
        meshRef.current.instanceMatrix.needsUpdate = true;
    });

    return <instancedMesh ref={meshRef} args={[undefined, undefined, count]}><dodecahedronGeometry args={[1, 0]} /><primitive object={asteroidMaterial} attach="material" /></instancedMesh>;
};

const CometSystem = () => {
    // VISIBLE INNER COMETS implementation details omitted for brevity as they are unchanged
    return <group></group>;
};

const LaunchSequence = ({ active, onComplete }: { active: boolean, onComplete: () => void }) => {
    const { camera, scene } = useThree();
    const startTimeRef = useRef(0);
    const startPosRef = useRef(new Vector3());

    useFrame((state) => {
        if (active) {
            if (startTimeRef.current === 0) {
                startTimeRef.current = state.clock.elapsedTime;
                startPosRef.current.copy(camera.position);
            }
            const elapsed = state.clock.elapsedTime - startTimeRef.current;
            const duration = 3.0; 
            const t = Math.min(elapsed / duration, 1);
            const ease = t * t * (3 - 2 * t); 
            // SCALED LAUNCH TARGET
            camera.position.lerpVectors(startPosRef.current, new Vector3(0, 0, 40000 * UNIVERSE_SCALE), ease);
            camera.lookAt(0, 0, 0);
            if (t >= 1) onComplete();
        } else { startTimeRef.current = 0; }
    });
    return null;
}

const SpaceshipController = ({ active, mouseSensitivity = 1.0, onDeath, isDead, mobileInputRef, shipPositionRef, asteroidDataRef, explosionRef, onScore, setFocusedBody, bodyGroupsRef, score = 0, onSpeedChange }: { active: boolean, mouseSensitivity?: number, onDeath?: (reason: 'collision') => void, isDead?: boolean, mobileInputRef?: React.MutableRefObject<any>, shipPositionRef: React.MutableRefObject<Vector3>, asteroidDataRef: React.MutableRefObject<AsteroidData[]>, explosionRef: React.MutableRefObject<any>, onScore?: () => void, setFocusedBody: (body: CelestialBodyData | null) => void, bodyGroupsRef: React.MutableRefObject<{[id: string]: Group}>, score?: number, onSpeedChange?: (s: number) => void }) => {
  const { camera, gl } = useThree();
  const velocity = useRef(new Vector3());
  const euler = useRef(new Euler(0, 0, 0, 'YXZ'));
  const lastShotTime = useRef(0);
  const lasers = useRef<{pos: Vector3, vel: Vector3, active: boolean}[]>([]);
  const laserMeshRef = useRef<InstancedMesh>(null);
  const laserDummy = useMemo(() => new THREE.Object3D(), []);
  const keys = useRef<{[key: string]: boolean}>({});
  const isFiring = useRef(false);

  useEffect(() => { if (active) euler.current.setFromQuaternion(camera.quaternion); }, [active, camera]);
  useLayoutEffect(() => { for(let i=0; i<100; i++) lasers.current.push({pos: new Vector3(), vel: new Vector3(), active: false}); }, []);

  useEffect(() => {
    const onMouseDown = () => { isFiring.current = true; if(!document.pointerLockElement) (gl.domElement.requestPointerLock() as any).catch(() => {}); };
    const onMouseUp = () => { isFiring.current = false; };
    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement && active && !isDead) {
        euler.current.setFromQuaternion(camera.quaternion);
        const SENS = 0.002 * mouseSensitivity;
        euler.current.y -= e.movementX * SENS;
        euler.current.x -= e.movementY * SENS;
        euler.current.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, euler.current.x));
        camera.quaternion.setFromEuler(euler.current);
      }
    };
    if (active) { document.addEventListener('mousedown', onMouseDown); document.addEventListener('mouseup', onMouseUp); document.addEventListener('mousemove', onMouseMove); }
    return () => { document.removeEventListener('mousedown', onMouseDown); document.removeEventListener('mouseup', onMouseUp); document.removeEventListener('mousemove', onMouseMove); };
  }, [active, isDead, camera, gl, mouseSensitivity]);

  useFrame((state, delta) => {
    if (!active || isDead) { velocity.current.set(0, 0, 0); soundManager.updateEngine(0); return; }
    
    // Collision Detection (Asteroids)
    if (asteroidDataRef.current) {
        const shipPos = camera.position;
        for (const ast of asteroidDataRef.current) {
            if (!ast.destroyed) {
                if (shipPos.distanceTo(ast.position) < ((ast.scale * ast.scales[0]) + (20 * UNIVERSE_SCALE))) {
                    onDeath && onDeath('collision'); break;
                }
            }
        }
    }

    // Rogue Planet Collision (Death Logic)
    if (bodyGroupsRef.current) {
        const shipPos = camera.position;
        for (const [id, group] of Object.entries(bodyGroupsRef.current)) {
            if (id.startsWith('rogue-') && group.visible) {
                const worldPos = new Vector3();
                group.getWorldPosition(worldPos);
                // Approximate radius for collision (visual scale / 2 roughly)
                if (shipPos.distanceTo(worldPos) < (2000 * UNIVERSE_SCALE)) {
                    onDeath && onDeath('collision');
                    break;
                }
            }
        }
    }

    // Shooting
    if (isFiring.current) {
        const now = Date.now();
        if (now - lastShotTime.current > 100) {  // Faster fire rate
            lastShotTime.current = now;
            soundManager.playLaser();
            const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
            const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
            const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
            
            const spawnLaser = (offsetMultiplier: number) => {
                const l = lasers.current.find(laser => !laser.active);
                if (l) {
                    l.active = true;
                    // SCALE LASER OFFSET
                    l.pos.copy(camera.position).add(forward.clone().multiplyScalar(15 * UNIVERSE_SCALE)).add(right.clone().multiplyScalar(12 * offsetMultiplier * UNIVERSE_SCALE)).add(up.clone().multiplyScalar(-2 * UNIVERSE_SCALE));
                    // SCALE LASER SPEED
                    l.vel.copy(forward).normalize().multiplyScalar(6000 * UNIVERSE_SCALE);
                }
            };
            spawnLaser(1); spawnLaser(-1);
        }
    }

    // Update Lasers & Destruction Logic
    if (laserMeshRef.current) {
        lasers.current.forEach((l, i) => {
            if (l.active) {
                l.pos.addScaledVector(l.vel, delta);
                
                // Asteroid Hit
                if (asteroidDataRef.current) {
                    for(const ast of asteroidDataRef.current) {
                        if (!ast.destroyed && l.pos.distanceTo(ast.position) < (ast.scale * 8.0)) { 
                            ast.destroyed = true; l.active = false; soundManager.playExplosion();
                            if (explosionRef.current) explosionRef.current.explode(ast.position, ast.scale); // Pass scale
                            if (onScore) onScore();
                            break; 
                        }
                    }
                }
                
                // Rogue Planet Hit (Destruction Logic)
                if (l.active && bodyGroupsRef.current) {
                    for (const [id, group] of Object.entries(bodyGroupsRef.current)) {
                        if (id.startsWith('rogue-') && group.visible) {
                            const worldPos = new Vector3();
                            group.getWorldPosition(worldPos);
                            if (l.pos.distanceTo(worldPos) < (5000 * UNIVERSE_SCALE)) {
                                group.visible = false; 
                                l.active = false;
                                soundManager.playExplosion();
                                if (explosionRef.current) explosionRef.current.explode(worldPos, 10); 
                                if (onScore) onScore(); 
                                break;
                            }
                        }
                    }
                }

                if (l.pos.distanceTo(camera.position) > (15000 * UNIVERSE_SCALE)) l.active = false;
                
                if (l.active) {
                    laserDummy.position.copy(l.pos); laserDummy.lookAt(l.pos.clone().add(l.vel)); 
                    // ENHANCED VISIBILITY: THICKER AND LONGER LASERS
                    laserDummy.scale.set(3 * UNIVERSE_SCALE, 3 * UNIVERSE_SCALE, 60 * UNIVERSE_SCALE); 
                    laserDummy.updateMatrix();
                    laserMeshRef.current!.setMatrixAt(i, laserDummy.matrix);
                }
            }
            if (!l.active) { laserDummy.scale.set(0,0,0); laserDummy.updateMatrix(); laserMeshRef.current!.setMatrixAt(i, laserDummy.matrix); }
        });
        laserMeshRef.current.instanceMatrix.needsUpdate = true;
    }

    // Movement
    const moveForward = keys.current['w'] || keys.current['arrowup'] || (mobileInputRef?.current?.y > 0);
    const moveBackward = keys.current['s'] || keys.current['arrowdown'] || (mobileInputRef?.current?.y < 0);
    const moveLeft = keys.current['a'] || keys.current['arrowleft'] || (mobileInputRef?.current?.x < 0);
    const moveRight = keys.current['d'] || keys.current['arrowright'] || (mobileInputRef?.current?.x > 0);
    const boost = keys.current['shift'];
    
    // SCALE SHIP SPEED
    const targetSpeed = (boost ? 200000 : 8000) * UNIVERSE_SCALE; 
    
    if (boost) {
        camera.position.x += (Math.random() - 0.5) * 50 * UNIVERSE_SCALE;
        camera.position.y += (Math.random() - 0.5) * 50 * UNIVERSE_SCALE;
    }

    const direction = new Vector3();
    const frontVector = new Vector3(0, 0, Number(moveBackward) - Number(moveForward));
    const sideVector = new Vector3(Number(moveLeft) - Number(moveRight), 0, 0);
    if (mobileInputRef?.current && (Math.abs(mobileInputRef.current.x) > 0.1 || Math.abs(mobileInputRef.current.y) > 0.1)) { frontVector.setZ(-mobileInputRef.current.y); sideVector.setX(mobileInputRef.current.x); }
    direction.subVectors(frontVector, sideVector).normalize().multiplyScalar(targetSpeed);
    direction.applyQuaternion(camera.quaternion);
    
    if (moveForward || moveBackward || moveLeft || moveRight) velocity.current.lerp(direction, 5 * delta);
    else velocity.current.lerp(new Vector3(0,0,0), 3 * delta); 
    
    const currentSpeed = velocity.current.length();
    
    // Pass FAKE (unscaled) speed to UI so it looks cool
    if (onSpeedChange && state.clock.elapsedTime % 0.1 < delta) {
        onSpeedChange(Math.round(currentSpeed / UNIVERSE_SCALE));
    }

    soundManager.updateEngine(Math.min(currentSpeed / (200000 * UNIVERSE_SCALE), 1));
    camera.position.addScaledVector(velocity.current, delta);
    shipPositionRef.current.copy(camera.position);

    if (mobileInputRef?.current && (Math.abs(mobileInputRef.current.lookX) > 0 || Math.abs(mobileInputRef.current.lookY) > 0)) {
        euler.current.setFromQuaternion(camera.quaternion);
        const SENS = 0.002 * mouseSensitivity;
        euler.current.y -= mobileInputRef.current.lookX * SENS * 10;
        euler.current.x -= mobileInputRef.current.lookY * SENS * 10;
        euler.current.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, euler.current.x));
        camera.quaternion.setFromEuler(euler.current);
    }
  });

  useEffect(() => {
    const down = (e: KeyboardEvent) => keys.current[e.key.toLowerCase()] = true;
    const up = (e: KeyboardEvent) => keys.current[e.key.toLowerCase()] = false;
    window.addEventListener('keydown', down); window.addEventListener('keyup', up);
    window.focus();
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); }
  }, []);

  return (
    <>
        <instancedMesh ref={laserMeshRef} args={[undefined, undefined, 100]}>
            <boxGeometry args={[1, 1, 1]} /> 
            {/* BRIGHTER LASER MATERIAL */}
            <meshBasicMaterial color="#00ffff" toneMapped={false} />
        </instancedMesh>
    </>
  );
};

const CameraManager = ({ viewMode, focusedBody, bodyGroups, controlsRef, launchState }: { viewMode: 'orbit' | 'spaceship', focusedBody: CelestialBodyData | null, bodyGroups: React.MutableRefObject<{[id: string]: Group}>, controlsRef: React.RefObject<CameraControls>, launchState?: string }) => {
    const prevFocusedBodyRef = useRef<string | null>(null);

    useEffect(() => {
        if (focusedBody && bodyGroups.current[focusedBody.id]) {
            // Focusing on a body
            const group = bodyGroups.current[focusedBody.id];
            const targetPos = new Vector3(); group.getWorldPosition(targetPos);
            const currentPos = new Vector3(); controlsRef.current?.getPosition(currentPos);
            // SCALE CAMERA FOLLOW DISTANCE
            let dist = (focusedBody.size * 4 + 1000) * UNIVERSE_SCALE;
            if (focusedBody.id === 'sun') dist = 40000 * UNIVERSE_SCALE;
            if (focusedBody.id === 'blackhole') dist = 150000 * UNIVERSE_SCALE;
            if (focusedBody.id.startsWith('rogue-')) dist = 200000 * UNIVERSE_SCALE;
            const direction = new Vector3().subVectors(currentPos, targetPos).normalize();
            if (direction.lengthSq() < 0.001) direction.set(0, 0, 1);
            const newEye = targetPos.clone().add(direction.multiplyScalar(dist));
            controlsRef.current?.setLookAt(newEye.x, newEye.y, newEye.z, targetPos.x, targetPos.y, targetPos.z, true);
        } else if (!focusedBody && prevFocusedBodyRef.current && viewMode === 'orbit') {
            // RETURNING TO ORBIT FROM A BODY (Reset to Home Position)
            // Use same coordinates as IntroSequence
            controlsRef.current?.setLookAt(
                0, 40000 * UNIVERSE_SCALE, 60000 * UNIVERSE_SCALE, // Position
                0, 0, 0, // Target (Sun)
                true // Animate
            );
        }
        
        prevFocusedBodyRef.current = focusedBody ? focusedBody.id : null;
    }, [focusedBody, viewMode]);

    useFrame((state, delta) => {
        if (launchState === 'animating') return; 
        if (viewMode === 'orbit') {
            if (focusedBody && bodyGroups.current[focusedBody.id]) {
                const group = bodyGroups.current[focusedBody.id];
                const pos = new Vector3(); group.getWorldPosition(pos);
                controlsRef.current?.setTarget(pos.x, pos.y, pos.z, true);
            } 
            // Note: We removed the else block that constantly set target to sun because
            // we handle the "return to home" transition once in the useEffect above.
            // This allows the user to pan around freely after returning.
        }
    });
    return null;
}

const SceneAudioHandler = () => {
    const { camera } = useThree();
    useFrame(() => {
        const dist = camera.position.length();
        soundManager.updateProximity(dist);
    });
    return null;
}

// INTRO SEQUENCE COMPONENT (MANUAL ANIMATION FOR SLOW ZOOM)
const IntroSequence = ({ onComplete }: { onComplete: () => void }) => {
    const { camera } = useThree();
    const startTimeRef = useRef(0);
    
    // Scaled positions: From deep space (30M) to orbit (40K)
    // 30,000,000 is ~750x farther than the final 40,000 position
    const startPos = useMemo(() => new Vector3(0, 30000000 * UNIVERSE_SCALE, 40000000 * UNIVERSE_SCALE), []);
    const endPos = useMemo(() => new Vector3(0, 40000 * UNIVERSE_SCALE, 60000 * UNIVERSE_SCALE), []);

    useFrame((state) => {
        if (startTimeRef.current === 0) startTimeRef.current = state.clock.elapsedTime;
        const elapsed = state.clock.elapsedTime - startTimeRef.current;
        const duration = 5.0; // SLOW ZOOM DURATION (5 Seconds)
        const t = Math.min(elapsed / duration, 1);
        
        // Easing: easeOutCubic (starts fast, slows down at the end)
        const ease = 1 - Math.pow(1 - t, 3);
        
        // Interpolate position
        camera.position.lerpVectors(startPos, endPos, ease);
        camera.lookAt(0, 0, 0);
        
        if (t >= 1) {
            onComplete();
        }
    });
    return null;
};

const SceneContent: React.FC<SceneProps> = ({ focusedBody, setFocusedBody, viewMode, onDeath, isDead, onReward, mouseSensitivity, mobileInputRef, onScore, onSystemClick, launchState, onLaunchComplete, score, onSpeedChange }) => {
    const controlsRef = useRef<CameraControls>(null);
    const shipPositionRef = useRef(new Vector3(100000, 200, 2500));
    const asteroidDataRef = useRef<AsteroidData[]>([]);
    const explosionRef = useRef<any>(null);
    const bodyGroups = useRef<{[id: string]: Group}>({});
    const registerRef = (id: string, group: Group) => { bodyGroups.current[id] = group; };
    const { scene, camera } = useThree(); 
    const solarSystemGroupRef = useRef<Group>(null);
    const [introFinished, setIntroFinished] = useState(false);
    
    // SCALE GALAXY CENTER
    const GALAXY_CENTER_POS: [number, number, number] = [4000000 * UNIVERSE_SCALE, 0, -1000000 * UNIVERSE_SCALE]; 

    // FIX: RESPAWN LOOP and DISTORTION
    useEffect(() => {
        if (!isDead && viewMode === 'orbit') {
             // SCALE INITIAL ORBIT POS - Will be handled by IntroSequence on mount
             if (camera instanceof THREE.PerspectiveCamera) {
                 camera.fov = 60;
                 camera.updateProjectionMatrix();
             }
        }
    }, [isDead, viewMode, camera]);

    useLayoutEffect(() => {
         if (controlsRef.current) {
             // Set default damping
             controlsRef.current.dampingFactor = 0.05;
         }
    }, []);

    useEffect(() => {
        const handleInteract = () => { soundManager.init(); };
        window.addEventListener('click', handleInteract); window.addEventListener('keydown', handleInteract);
        return () => { window.removeEventListener('click', handleInteract); window.removeEventListener('keydown', handleInteract); };
    }, []);

    return (
        <>
            <fog attach="fog" args={['#000000', 2000000 * UNIVERSE_SCALE, 500000000 * UNIVERSE_SCALE]} />
            <ambientLight intensity={0.05} />
            <UniverseStars />
            <group position={GALAXY_CENTER_POS} rotation={[0, 0, 0]}>
                <BlackHole 
                    position={[0, 0, 0]} 
                    onClick={() => {
                        setFocusedBody({
                            id: 'blackhole', type: 'planet', name: 'TON 618', description: 'Supermassive Black Hole',
                            about: 'The gravitational anchor of this galaxy.', color: '#ff6600', size: 50000, orbitRadius: 0, orbitSpeed: 0, details: ['Mass: 66 Billion Solar Masses', 'Event Horizon: 50,000 KM', 'Status: Active']
                        });
                    }}
                    onDeath={onDeath}
                    viewMode={viewMode}
                    registerRef={registerRef}
                    isDead={isDead}
                />
                <RogueSystems setFocusedBody={setFocusedBody} onDeath={() => onDeath && onDeath('collision')} viewMode={viewMode} registerRef={registerRef} />
                <GalacticHazards shipPosition={shipPositionRef} onDeath={() => onDeath && onDeath('collision')} active={viewMode === 'spaceship'} />
            </group>

            <group ref={solarSystemGroupRef} name="SolarSystemGroup">
                 <group position={[0, 0, 0]}>
                    <pointLight position={[0, 0, 0]} intensity={3.5} distance={200000 * UNIVERSE_SCALE} decay={1} color="#FDB813" />
                    <group ref={group => { if(group) bodyGroups.current['sun'] = group; }}>
                        <CelestialBody 
                            data={SOLAR_SYSTEM_DATA} 
                            onFocus={(data, pos) => { setFocusedBody(data); }} 
                            focusedBodyId={focusedBody?.id || null} 
                            viewMode={viewMode} 
                            registerRef={registerRef} 
                            globalScale={UNIVERSE_SCALE} 
                        />
                    </group>
                    <AsteroidField shipPosition={shipPositionRef} onCollision={() => { if(!isDead) onDeath && onDeath('collision'); }} gracePeriod={launchState !== 'flying'} asteroidDataRef={asteroidDataRef} viewMode={viewMode} />
                    <CometSystem />
                 </group>
            </group>
            
            <ExplosionSystem ref={explosionRef} />

            {viewMode === 'spaceship' && !isDead && launchState === 'flying' && (
                <>
                    <SpaceshipController 
                        active={true} mouseSensitivity={mouseSensitivity} onDeath={onDeath} isDead={isDead} mobileInputRef={mobileInputRef} shipPositionRef={shipPositionRef} asteroidDataRef={asteroidDataRef} explosionRef={explosionRef} onScore={onScore} setFocusedBody={setFocusedBody} score={score}
                        bodyGroupsRef={bodyGroups} onSpeedChange={onSpeedChange}
                    />
                    <ShipLights defaultOn={true} />
                </>
            )}

            <LaunchSequence active={launchState === 'animating'} onComplete={onLaunchComplete!} />
            {viewMode === 'orbit' && launchState !== 'animating' && (
                <>
                    <CameraControls 
                        ref={controlsRef} 
                        maxDistance={30000000 * UNIVERSE_SCALE} 
                        minDistance={100 * UNIVERSE_SCALE} 
                        enabled={introFinished} // ENABLE CONTROLS ONLY AFTER INTRO
                        smoothTime={0.8} 
                    />
                    {!introFinished && (
                        <IntroSequence onComplete={() => {
                            setIntroFinished(true);
                            // SYNC CONTROLS TO END POSITION
                            if (controlsRef.current) {
                                controlsRef.current.setLookAt(
                                    0, 40000 * UNIVERSE_SCALE, 60000 * UNIVERSE_SCALE,
                                    0, 0, 0,
                                    false 
                                );
                            }
                        }} />
                    )}
                </>
            )}
            <CameraManager viewMode={viewMode} focusedBody={focusedBody} bodyGroups={bodyGroups} controlsRef={controlsRef} launchState={launchState} />
            <SceneAudioHandler />
        </>
    );
};

const Scene: React.FC<SceneProps> = (props) => {
  return (
    // SCALE CAMERA FAR PLANE: 50M * UNIVERSE_SCALE to prevent Z-Fighting
    <Canvas camera={{ position: [0, 40000 * UNIVERSE_SCALE, 60000 * UNIVERSE_SCALE], fov: 60, far: 500000000 * UNIVERSE_SCALE }} gl={{ logarithmicDepthBuffer: true, antialias: true, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.0 }} dpr={[1, 2]}>
        <Suspense fallback={null}><SceneContent {...props} /></Suspense>
    </Canvas>
  );
};

export default Scene;
