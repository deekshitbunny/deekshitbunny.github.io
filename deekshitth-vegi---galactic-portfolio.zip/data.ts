
import { CelestialBodyData } from './types';

// Change this number when you turn 26 to automatically add a new star system!
export const AUTHOR_AGE = 25;

// Define the type of system for each index (0 to AUTHOR_AGE-1).
// TO ADD A NEW STAR:
// 1. Increase AUTHOR_AGE above.
// 2. Add 'single', 'binary', or 'trinary' to the end of this array.
export const STAR_SYSTEM_TYPES: ('single' | 'binary' | 'trinary')[] = [
    'binary', 'binary', 'trinary', 
    'single', 'single', 'single', 'single', 'single',
    'single', 'single', 'single', 'single', 'single',
    'single', 'single', 'single', 'single', 'single',
    'single', 'single', 'single', 'single', 'single',
    'single', 'single'
];

export const SOLAR_SYSTEM_DATA: CelestialBodyData = {
  id: 'sun',
  type: 'sun',
  name: 'Deekshitth Vegi',
  description: 'M.S. in Artificial Intelligence | AI/ML Engineer | Researcher',
  about: "I am an AI researcher and engineer passionate about building intelligent systems that solve real-world problems. With a strong foundation in Deep Learning, NLP, and Computer Vision, I specialize in creating scalable AI solutions. My research focuses on evaluating Large Language Models and enhancing their reliability in educational contexts. I love exploring the cosmos of code and uncovering the secrets of data.",
  color: '#FDB813', 
  size: 8000, 
  orbitRadius: 0,
  orbitSpeed: 0,
  inclination: 0,
  details: [
    'Thesis: Automated Methods to Evaluate the Quality of Distractors in College-Level MCQs using LLMs',
    'Email: deekshitvegibunny@gmail.com',
    'Phone: +1 940 843 6087',
    'Location: Irving, TX',
    'HuggingFace: huggingface.co/Wendgan',
    'LinkedIn: linkedin.com/in/deekshitthvegi',
    'Github: github.com/deekshitvegi'
  ],
  moons: [
    {
      id: 'education',
      type: 'planet',
      name: 'Education',
      description: 'Academic Background',
      color: '#38bdf8', 
      size: 900, 
      orbitRadius: 20000, 
      orbitSpeed: 0.05, 
      rotationSpeed: 0.005,
      inclination: 0.2,
      moons: [
        {
          id: 'unt',
          type: 'moon',
          name: 'Univ. of North Texas',
          description: 'M.S. in Artificial Intelligence',
          date: 'Aug 2023 – Jul 2025',
          location: 'Denton, TX',
          color: '#0ea5e9', 
          size: 150, 
          orbitRadius: 1600,
          orbitSpeed: 0.2,
          inclination: -0.5,
          details: [
            'GPA: 3.33/4.0',
            'Relevant Coursework: Deep Learning, NLP, Computer Vision, Perceptron Models, AI',
            'Thesis on LLM Distractor Quality Evaluation'
          ]
        },
        {
          id: 'iiitdm',
          type: 'moon',
          name: 'IIITDM Kurnool',
          description: 'B.Tech. in Mechanical Engineering',
          date: 'Aug 2019 – May 2023',
          location: 'Kurnool, India',
          color: '#0ea5e9',
          size: 130, 
          orbitRadius: 2200, 
          orbitSpeed: 0.15,
          inclination: 0.3,
          details: [
            'Relevant Coursework: CAD, Solid Modeling, 3D Printing, Simulation'
          ]
        }
      ]
    },
    {
      id: 'experience',
      type: 'planet',
      name: 'Experience',
      description: 'Professional History',
      color: '#ef4444', 
      size: 1100, 
      orbitRadius: 32000, 
      orbitSpeed: 0.02, 
      rotationSpeed: 0.004,
      inclination: -0.15,
      moons: [
        {
          id: 'unt-researcher',
          type: 'moon',
          name: 'Graduate Thesis Researcher',
          description: 'University of North Texas',
          date: 'Aug 2024 – Jul 2025',
          color: '#f87171',
          size: 150,
          orbitRadius: 1800,
          orbitSpeed: 0.3,
          inclination: 0.4,
          details: [
            'Evaluated distractor quality in MCQs using LLMs (GPT-4, Claude, Gemini) on a 500+ question benchmark.',
            'Implemented ranking strategies: direct, scoring, explanation-based, pairwise.',
            'Benchmarked encoder (BERT, RoBERTa) and decoder models.',
            'Statistical analysis: Spearman correlation, p-values, rank accuracy.'
          ]
        },
        {
          id: 'innomatics',
          type: 'moon',
          name: 'Data Science Intern',
          description: 'Innomatics Research Labs',
          date: 'Sep 2022 – Jun 2023',
          color: '#f87171',
          size: 140,
          orbitRadius: 2400,
          orbitSpeed: 0.25,
          inclination: -0.2,
          details: [
            'Built NLP pipelines for tweet classification and recommender systems.',
            'Designed and deployed a Spotify recommender using audio feature vectors.',
            'Performed feature engineering and model tuning.'
          ]
        },
        {
          id: 'josh',
          type: 'moon',
          name: 'Software Dev Intern',
          description: 'Josh Innovations',
          date: 'Jun 2022 – Oct 2022',
          color: '#f87171',
          size: 130,
          orbitRadius: 2900,
          orbitSpeed: 0.2,
          inclination: 0.1,
          details: [
            'Developed full-stack applications using ReactJS and Node.js.',
            'Implemented real-time UI interactions and reusable components.'
          ]
        },
        {
          id: 'drdo',
          type: 'moon',
          name: 'Research Intern',
          description: 'DRDO, Ministry of Defense',
          date: 'May 2022 – Oct 2022',
          color: '#f87171',
          size: 130,
          orbitRadius: 3400,
          orbitSpeed: 0.15,
          inclination: -0.3,
          details: [
            'Designed and analyzed composite security structures for defense applications.',
            'Delivered high-strength prototypes meeting test standards.'
          ]
        }
      ]
    },
    {
      id: 'projects',
      type: 'planet',
      name: 'Projects',
      description: 'Key Technical Projects',
      color: '#10b981', 
      size: 1800, 
      orbitRadius: 48000, 
      orbitSpeed: 0.01, 
      rotationSpeed: 0.006,
      inclination: 0.25,
      rings: [
          { innerRadius: 2200, outerRadius: 2900, color: '#34d399', opacity: 0.6, rotation: [-Math.PI/2, 0, 0] },
          { innerRadius: 3000, outerRadius: 3600, color: '#6ee7b7', opacity: 0.4, rotation: [-Math.PI/2, 0, 0] },
          { innerRadius: 3700, outerRadius: 4100, color: '#a7f3d0', opacity: 0.3, rotation: [-Math.PI/2, 0, 0] }
      ],
      moons: [
        {
          id: 'exoplanet_tool',
          type: 'moon',
          name: 'Exoplanet Detector',
          description: 'Interactive Transit Classifier',
          color: '#34d399',
          size: 160,
          orbitRadius: 4500, 
          orbitSpeed: 0.25,
          inclination: 0.5,
          details: [
            'Interactive Tool Available',
            'Generated dataset of 150,000 synthetic light curves.',
            'Built LSTM/Transformer pipeline for transit classification.',
            'Integrated 3D orbit simulation.'
          ]
        },
        {
          id: 'pose',
          type: 'moon',
          name: '2D to 3D Pose',
          description: 'Computer Vision',
          color: '#34d399',
          size: 150,
          orbitRadius: 5200,
          orbitSpeed: 0.2,
          inclination: -0.4,
          details: [
            'Extracted 2D keypoints from RGB video using MediaPipe.',
            'Reconstructed 3D poses with temporal filtering and regression.'
          ]
        },
        {
          id: 'wiki',
          type: 'moon',
          name: 'Wiki Image Captioning',
          description: 'Multimodal AI',
          color: '#34d399',
          size: 150,
          orbitRadius: 5900, 
          orbitSpeed: 0.15,
          inclination: 0.2,
          details: [
            'Compared BLIP/CLIP embeddings with custom LSTM decoder.',
            'Evaluated with BLEU/CIDEr scores.',
            'Deployed on Hugging Face Spaces.'
          ]
        },
        {
          id: 'scanner',
          type: 'moon',
          name: 'Product Scanner',
          description: 'Health Analyzer',
          color: '#34d399',
          size: 140,
          orbitRadius: 6600,
          orbitSpeed: 0.12,
          inclination: -0.1,
          details: [
            'Barcode scanning with Flask+SQLAlchemy.',
            'AI health scoring and recommendations via REST APIs.'
          ]
        }
      ]
    },
    {
      id: 'skills',
      type: 'planet',
      name: 'Skills',
      description: 'Technical Proficiency',
      color: '#8b5cf6', 
      size: 900, 
      orbitRadius: 64000, 
      orbitSpeed: 0.003, 
      rotationSpeed: 0.008,
      inclination: -0.1,
      moons: [
        {
          id: 'lang',
          type: 'moon',
          name: 'Programming',
          description: 'Core Languages',
          color: '#a78bfa',
          size: 130,
          orbitRadius: 1300,
          orbitSpeed: 0.3,
          inclination: 0.3,
          details: ['Python', 'SQL', 'JavaScript', 'C#']
        },
        {
          id: 'web',
          type: 'moon',
          name: 'Web Dev',
          description: 'Frontend/Backend',
          color: '#a78bfa',
          size: 130,
          orbitRadius: 1800,
          orbitSpeed: 0.25,
          inclination: -0.2,
          details: ['HTML', 'CSS', 'Bootstrap', 'ReactJS', 'Node.js']
        },
        {
          id: 'ai',
          type: 'moon',
          name: 'AI / ML',
          description: 'Frameworks & Models',
          color: '#a78bfa',
          size: 130,
          orbitRadius: 2300,
          orbitSpeed: 0.2,
          inclination: 0.4,
          details: ['PyTorch', 'TensorFlow', 'Hugging Face', 'scikit-learn', 'Transformers', 'GPT', 'BERT', 'OpenCV']
        },
        {
          id: 'tools',
          type: 'moon',
          name: 'Tools & Viz',
          description: 'Utilities',
          color: '#a78bfa',
          size: 130,
          orbitRadius: 2800,
          orbitSpeed: 0.15,
          inclination: -0.3,
          details: ['AWS (S3)', 'FastAPI', 'MongoDB', 'Docker', 'Tableau', 'Gradio', 'SOLIDWORKS']
        }
      ]
    }
  ]
};
