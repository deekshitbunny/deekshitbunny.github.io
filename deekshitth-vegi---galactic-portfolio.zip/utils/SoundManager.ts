
export class SoundManager {
  ctx: AudioContext | null = null;
  masterGain: GainNode | null = null;
  engineOsc: OscillatorNode | null = null;
  engineGain: GainNode | null = null;
  sunOsc: OscillatorNode | null = null;
  sunGain: GainNode | null = null;
  initialized: boolean = false;

  init() {
    if (this.initialized) {
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
        return;
    }
    
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.3; // Master volume
    this.masterGain.connect(this.ctx.destination);
    
    // --- ENGINE DRONE (Sawtooth + Lowpass) ---
    this.engineOsc = this.ctx.createOscillator();
    this.engineOsc.type = 'sawtooth';
    this.engineOsc.frequency.value = 50;
    
    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = 0;
    
    // Filter for engine
    const engineFilter = this.ctx.createBiquadFilter();
    engineFilter.type = 'lowpass';
    engineFilter.frequency.value = 200;

    this.engineOsc.connect(engineFilter);
    engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.masterGain);
    this.engineOsc.start();

    // --- SUN AMBIENCE (Deep Sine) ---
    this.sunOsc = this.ctx.createOscillator();
    this.sunOsc.type = 'sine';
    this.sunOsc.frequency.value = 60; // 60Hz hum
    
    this.sunGain = this.ctx.createGain();
    this.sunGain.gain.value = 0;
    
    this.sunOsc.connect(this.sunGain);
    this.sunGain.connect(this.masterGain);
    this.sunOsc.start();

    this.initialized = true;
  }

  playLaser() {
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'square';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(100, t + 0.15);
    
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    
    osc.connect(gain);
    gain.connect(this.masterGain);
    
    osc.start();
    osc.stop(t + 0.2);
  }

  playExplosion() {
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    
    // Create Noise Buffer
    const bufferSize = this.ctx.sampleRate * 0.5; // 0.5 sec
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
    }
    
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, t);
    filter.frequency.exponentialRampToValueAtTime(100, t + 0.4);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    
    noise.start();
  }

  updateEngine(speedRatio: number) {
     if (!this.engineOsc || !this.engineGain || !this.ctx) return;
     // speedRatio is 0 to 1
     const targetFreq = 50 + (speedRatio * 150);
     const targetVol = Math.min(speedRatio * 0.15, 0.15);
     
     this.engineOsc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.1);
     this.engineGain.gain.setTargetAtTime(targetVol, this.ctx.currentTime, 0.1);
  }

  updateProximity(distToSun: number) {
      if (!this.sunGain || !this.ctx) return;
      // Closer = louder. Max effect within 5000 units.
      // distToSun goes from 0 to ~15000
      let volume = 0;
      if (distToSun < 5000) {
          volume = (1 - (distToSun / 5000)) * 0.2; // Max vol 0.2
      }
      this.sunGain.gain.setTargetAtTime(volume, this.ctx.currentTime, 0.5);
  }
}

export const soundManager = new SoundManager();