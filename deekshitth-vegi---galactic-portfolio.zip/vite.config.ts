
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
      },
      plugins: [react()],
      define: {
        // Inject API key from environment, or use empty string if missing (allows error handling logic to run)
        'process.env.API_KEY': JSON.stringify(env.API_KEY || env.GEMINI_API_KEY || ""),
      },
      resolve: {
        alias: {
          '@': path.resolve('.'),
        }
      },
      base: '/', // Ensure assets are loaded from root in production
    };
});
